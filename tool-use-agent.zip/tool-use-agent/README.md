# Your first tool-using AI

A short script where an AI model can call **one function**, `lookup_price`, which reads a price from a local file (`prices.csv`). Standard library only: no installs.

```bash
python tool_agent.py "How much is the steel flask?" --mock          # offline demo, no key needed
export ANTHROPIC_API_KEY=...                                         # for the real model
python tool_agent.py "How much is the steel flask?"
python -m unittest discover -s tests -t .                            # 14 offline tests
```

Output of the offline demo (the `--mock` client stands in for the model):

```
[turn 1] model stop_reason = tool_use
         model asks: lookup_price({"product_name": "steel flask"})
         we ran it -> {"found": true, "product": "Steel flask 500 ml", "price_aed": 59.0, "in_stock": true}
[turn 2] model stop_reason = end_turn

ANSWER: Steel flask 500 ml costs AED 59.00 and is in stock.
```

## The key idea

**The model never runs your function.** It can only *ask* for it, in a structured message. Your code runs the function and sends the result back. The model then reads the result and writes its answer. Everything below is that one idea, step by step.

## The tool-use loop, step by step

The loop is `run_agent()` in `tool_agent.py`.

**Step 0. Write the function and describe it.**
`lookup_price(product_name)` reads `prices.csv`. `TOOLS` describes it to the model: a name, a plain-English description of *when* to use it, and a JSON schema for its input. The model only ever sees this description, never your code.

**Step A. Send the question and the tool list.**
`client.create(messages, TOOLS, SYSTEM)` sends the customer's question plus the tool description to the model.

**Step B. The model decides.**
If it can answer without help, it replies with text and `stop_reason: "end_turn"`. If it needs the price, it replies with a `tool_use` block, `{"name": "lookup_price", "input": {"product_name": "steel flask"}, "id": "toolu_..."}`, and `stop_reason: "tool_use"`. That means: *please run this and tell me what happened.* Nothing has run yet.

**Step C. Your code runs the function.**
`_run_tool()` looks the name up in `FUNCTIONS`, calls it with the model's arguments, and captures the result. If anything goes wrong (unknown tool, bad arguments, missing file) it returns a short `Error: ...` with `is_error: true` instead of crashing, so the model can react.

**Step D. Send the result back.**
The reply goes into the conversation as a `tool_result` block that carries the same `tool_use_id`, so the model can match answer to request. The history now reads: user question, assistant `tool_use`, user `tool_result`. The API requires that exact order.

**Step E. The model answers.**
The loop calls the model again with the longer history. This time it has the price, so it writes the final sentence and `stop_reason` is `end_turn`. The loop returns that text. If it asked for another tool instead, the loop would go round again.

```
question ──> model ──tool_use──> your code runs lookup_price ──tool_result──> model ──text──> answer
               ^                                                               |
               └─────────────── repeat while stop_reason == "tool_use" ────────┘
```

## Safety rules built into the loop

- **Turn limit** (`max_turns=5`): a model that keeps calling tools cannot loop forever.
- **Errors go back to the model as results,** not as crashes, and never as a raw traceback.
- **The function is read-only.** The model can look things up but cannot change anything.
- **Treat the model's arguments as untrusted input.** `lookup_price` checks its argument and only reads one fixed file, so the model cannot ask it to open another.
- **The system prompt says "answer only from tool results"** so the model does not invent a price when the lookup finds nothing.

## Files

| File | What it is |
| --- | --- |
| `tool_agent.py` | The function, the tool description, the loop, the real API client and the offline mock |
| `prices.csv` | The local file the function reads |
| `tests/test_agent.py` | 14 offline tests: the lookup, the loop, error handling, the turn limit, the shape of the history |

## Limits

- **Not run against the live API.** The real client is tested only against a local fake server, which checks the request shape. Run it once with your key before relying on it.
- The `--mock` client is a small script, not a language model. It exists to show the loop and to test it offline.
- One tool, one product per question. To add a tool, add its description to `TOOLS` and its function to `FUNCTIONS`.
