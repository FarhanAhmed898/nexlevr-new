import json
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer

import tool_agent as t


class Lookup(unittest.TestCase):
    def test_exact(self): self.assertEqual(t.lookup_price("Steel flask 500 ml")["price_aed"], 59.0)
    def test_partial_and_case(self): self.assertEqual(t.lookup_price("steel flask")["product"], "Steel flask 500 ml")
    def test_out_of_stock(self): self.assertFalse(t.lookup_price("cotton crew tee")["in_stock"])
    def test_not_found_lists_products(self):
        r = t.lookup_price("laptop"); self.assertFalse(r["found"]); self.assertIn("USB-C charger 65W", r["available_products"])
    def test_bad_input(self):
        with self.assertRaises(ValueError): t.lookup_price("  ")


class Loop(unittest.TestCase):
    def test_tool_is_called_then_answer(self):
        out = t.run_agent("How much is the steel flask?", t.MockClient(), verbose=False)
        self.assertIn("AED 59.00", out); self.assertIn("in stock", out)

    def test_no_tool_needed(self):
        self.assertIn("prices", t.run_agent("Hello", t.MockClient(), verbose=False))

    def test_history_shape(self):  # the API needs assistant tool_use then a user tool_result with the same id
        seen = []
        class Spy(t.MockClient):
            def create(self, messages, tools, system): seen.append(json.loads(json.dumps(messages))); return super().create(messages, tools, system)
        t.run_agent("price of the steel flask", Spy(), verbose=False)
        last = seen[-1]
        self.assertEqual([m["role"] for m in last], ["user", "assistant", "user"])
        self.assertEqual(last[1]["content"][0]["id"], last[2]["content"][0]["tool_use_id"])

    def test_unknown_tool_becomes_error_result(self):
        r = t._run_tool({"id": "x", "name": "delete_everything", "input": {}}, False)
        self.assertTrue(r["is_error"]); self.assertIn("unknown tool", r["content"])

    def test_bad_arguments_become_error_result(self):
        r = t._run_tool({"id": "x", "name": "lookup_price", "input": {"wrong": 1}}, False)
        self.assertTrue(r["is_error"])

    def test_turn_limit(self):
        class Forever:
            def create(self, m, tl, s): return {"stop_reason": "tool_use", "content": [{"type": "tool_use", "id": "i", "name": "lookup_price", "input": {"product_name": "x"}}]}
        self.assertIn("turn limit", t.run_agent("q", Forever(), max_turns=3, verbose=False))

    def test_not_found_answer(self):
        self.assertIn("could not find", t.run_agent("price of the laptop", t.MockClient(), verbose=False))


class Backend(unittest.TestCase):
    """The real client against a local fake server: checks the request shape only."""
    def test_request_shape(self):
        got = {}
        class H(BaseHTTPRequestHandler):
            def do_POST(self):
                got["body"] = json.loads(self.rfile.read(int(self.headers["content-length"]))); got["key"] = self.headers["x-api-key"]
                out = json.dumps({"stop_reason": "end_turn", "content": [{"type": "text", "text": "ok"}]}).encode()
                self.send_response(200); self.send_header("content-length", str(len(out))); self.end_headers(); self.wfile.write(out)
            def log_message(self, *a): pass
        srv = HTTPServer(("127.0.0.1", 0), H); threading.Thread(target=srv.handle_request, daemon=True).start()
        import os; os.environ["ANTHROPIC_API_KEY"] = "k"; os.environ["ANTHROPIC_BASE_URL"] = f"http://127.0.0.1:{srv.server_port}"
        r = t.AnthropicClient().create([{"role": "user", "content": "hi"}], t.TOOLS, t.SYSTEM)
        self.assertEqual(r["stop_reason"], "end_turn"); self.assertEqual(got["key"], "k")
        self.assertEqual(got["body"]["tools"][0]["name"], "lookup_price"); self.assertIn("system", got["body"])

    def test_missing_key(self):
        import os; os.environ.pop("ANTHROPIC_API_KEY", None)
        with self.assertRaises(RuntimeError): t.AnthropicClient().create([], t.TOOLS, t.SYSTEM)


if __name__ == "__main__":
    unittest.main()
