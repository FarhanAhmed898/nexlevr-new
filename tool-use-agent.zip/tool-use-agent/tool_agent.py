"""A first tool-using AI: the model may call ONE function, lookup_price, which reads prices.csv.

    python tool_agent.py "How much are the steel flasks?" --mock      # offline, no API key
    ANTHROPIC_API_KEY=... python tool_agent.py "How much are the steel flasks?"

Standard library only. The loop is in run_agent(); read it first.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

PRICE_FILE = Path(__file__).with_name("prices.csv")

# ---------------------------------------------------------------- 1. the function ---
def lookup_price(product_name: str, price_file: Path = PRICE_FILE) -> dict:
    """Read-only lookup in a local CSV. Returns a dict the model can read."""
    if not isinstance(product_name, str) or not product_name.strip():
        raise ValueError("product_name must be a non-empty string")
    wanted = product_name.strip().lower()
    with open(price_file, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    for row in rows:  # exact match first, then "the query is part of the name"
        if row["product"].lower() == wanted:
            return _found(row)
    for row in rows:
        if wanted in row["product"].lower() or row["product"].lower() in wanted:
            return _found(row)
    return {"found": False, "message": "no product with that name", "available_products": [r["product"] for r in rows]}


def _found(row: dict) -> dict:
    return {"found": True, "product": row["product"], "price_aed": float(row["price_aed"]), "in_stock": row["in_stock"] == "yes"}


# ---------------------------------------------------------------- 2. the tool description the model sees ---
TOOLS = [{
    "name": "lookup_price",
    "description": "Look up the current price (in AED) and stock status of one product in the shop's price list. "
                   "Use it whenever the customer asks about a price or whether something is in stock. Never guess a price.",
    "input_schema": {
        "type": "object",
        "properties": {"product_name": {"type": "string", "description": "Product name as the customer wrote it, e.g. 'steel flask'"}},
        "required": ["product_name"],
    },
}]
FUNCTIONS = {"lookup_price": lookup_price}
SYSTEM = "You are a shop assistant. Answer only from tool results. If the tool finds nothing, say so and list what is available."


# ---------------------------------------------------------------- 3. the loop ---
def run_agent(question: str, client, max_turns: int = 5, verbose: bool = True) -> str:
    messages = [{"role": "user", "content": question}]
    for turn in range(1, max_turns + 1):
        reply = client.create(messages, TOOLS, SYSTEM)                      # STEP A: ask the model
        messages.append({"role": "assistant", "content": reply["content"]})  # keep its reply in the history
        if verbose:
            print(f"[turn {turn}] model stop_reason = {reply['stop_reason']}")
        if reply["stop_reason"] != "tool_use":                               # STEP E: no tool wanted, so this is the answer
            return "".join(b["text"] for b in reply["content"] if b["type"] == "text")
        results = []
        for block in reply["content"]:
            if block["type"] != "tool_use":
                continue
            if verbose:
                print(f"         model asks: {block['name']}({json.dumps(block['input'])})")
            results.append(_run_tool(block, verbose))                        # STEP B + C: run it ourselves
        messages.append({"role": "user", "content": results})                # STEP D: hand the results back
    return "Stopped: the model kept calling tools and hit the turn limit."


def _run_tool(block: dict, verbose: bool) -> dict:
    func = FUNCTIONS.get(block["name"])
    try:
        if func is None:
            raise KeyError(f"unknown tool {block['name']!r}")
        output, is_error = json.dumps(func(**block["input"])), False
    except Exception as exc:  # the model never sees a traceback, only a short error it can react to
        output, is_error = f"Error: {exc}", True
    if verbose:
        print(f"         we ran it -> {output}")
    return {"type": "tool_result", "tool_use_id": block["id"], "content": output, **({"is_error": True} if is_error else {})}


# ---------------------------------------------------------------- model clients ---
class AnthropicClient:
    """Real Messages API call. Needs ANTHROPIC_API_KEY. Not run live in this repo's tests."""

    def __init__(self, model="claude-haiku-5-5", max_tokens=600):
        self.model, self.max_tokens = model, max_tokens
        self.key = os.environ.get("ANTHROPIC_API_KEY", "")
        self.base = os.environ.get("ANTHROPIC_BASE_URL", "https://api.anthropic.com").rstrip("/")

    def create(self, messages, tools, system):
        if not self.key:
            raise RuntimeError("ANTHROPIC_API_KEY is not set (use --mock to run offline)")
        body = json.dumps({"model": self.model, "max_tokens": self.max_tokens, "system": system,
                           "tools": tools, "messages": messages}).encode()
        req = urllib.request.Request(f"{self.base}/v1/messages", data=body, headers={
            "x-api-key": self.key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
        for attempt in range(4):
            try:
                with urllib.request.urlopen(req, timeout=120) as r:
                    return json.load(r)
            except urllib.error.HTTPError as e:
                if e.code in (429, 500, 502, 503, 529) and attempt < 3:
                    time.sleep(2 ** attempt)
                    continue
                raise RuntimeError(f"API error {e.code}: {e.read().decode()[:300]}") from e


class MockClient:
    """Offline stand-in that behaves like the API for this one job, so the loop can run with no key.
    It asks for the tool when the question mentions price/cost/stock, then writes the answer from the tool result.
    It is NOT a language model."""

    def create(self, messages, tools, system):
        last = messages[-1]
        if isinstance(last["content"], str):
            q = last["content"].lower()
            if any(w in q for w in ("price", "cost", "how much", "stock")):
                name = q.replace("?", "").split(" the ")[-1].split(" for ")[-1].strip()
                return {"stop_reason": "tool_use", "content": [
                    {"type": "tool_use", "id": "toolu_mock_1", "name": "lookup_price", "input": {"product_name": name}}]}
            return {"stop_reason": "end_turn", "content": [{"type": "text", "text": "I can help with prices and stock."}]}
        result = last["content"][0]
        if result.get("is_error"):
            text = "Sorry, I could not look that up."
        else:
            data = json.loads(result["content"])
            if data["found"]:
                text = f"{data['product']} costs AED {data['price_aed']:.2f} and is {'in stock' if data['in_stock'] else 'out of stock'}."
            else:
                text = "I could not find that product. We have: " + ", ".join(data["available_products"]) + "."
        return {"stop_reason": "end_turn", "content": [{"type": "text", "text": text}]}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Ask the shop assistant about a price.")
    ap.add_argument("question")
    ap.add_argument("--mock", action="store_true", help="use the offline mock instead of the real API")
    ap.add_argument("--model", default="claude-haiku-5-5")
    a = ap.parse_args(argv)
    client = MockClient() if a.mock else AnthropicClient(a.model)
    print("\nANSWER:", run_agent(a.question, client))
    return 0


if __name__ == "__main__":
    sys.exit(main())
