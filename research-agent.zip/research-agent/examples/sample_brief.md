<!-- Fictional company, scripted mock model, fixture page. Shows the format only. -->
# Example Bakery (fictional): research brief

## What they sell
- Sells sourdough bread, croissants and custom birthday cakes [S1]

## Who their customers are
- Customers are in Sharjah and Dubai [S1]

## Online presence
- Takes orders online and is on Instagram [S1]

## Three growth ideas (our suggestions, not facts)
1. Corporate breakfast boxes. Dubai offices already fall inside the delivery area [builds on S1]
2. Weekly bread subscription. online ordering exists, so repeat orders are the next step [builds on S1]
3. Instagram cake gallery. custom cakes sell on visuals [builds on S1]

## Could not verify
- (online_presence) Has 12 branches: quote not found on the cited page

## Sources
- [S1] https://example.test/a
