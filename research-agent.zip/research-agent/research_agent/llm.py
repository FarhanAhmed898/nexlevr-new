"""Model clients. AnthropicClient needs ANTHROPIC_API_KEY; MockClient is for tests."""
import json
import os
import urllib.request

MODEL = os.environ.get("RESEARCH_MODEL", "claude-sonnet-5-5")


class AnthropicClient:
    def __init__(self, api_key=None, model=MODEL):
        self.key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not self.key:
            raise SystemExit("Set ANTHROPIC_API_KEY (or run with --mock for a demo).")
        self.model = model

    def complete(self, system: str, user: str) -> str:
        body = json.dumps({"model": self.model, "max_tokens": 2000, "system": system,
                           "messages": [{"role": "user", "content": user}]}).encode()
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages", data=body,
            headers={"x-api-key": self.key, "anthropic-version": "2023-06-01",
                     "content-type": "application/json"})
        with urllib.request.urlopen(req, timeout=120) as r:
            data = json.load(r)
        return "".join(b.get("text", "") for b in data["content"] if b["type"] == "text")


class MockClient:
    """Returns scripted replies in order. Not a language model."""

    def __init__(self, replies):
        self.replies, self.calls = list(replies), []

    def complete(self, system, user):
        self.calls.append(user)
        return self.replies.pop(0)
