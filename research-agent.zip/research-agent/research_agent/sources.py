"""Find and fetch public pages. Standard library only."""
import re
import urllib.parse
import urllib.request
from dataclasses import dataclass
from html.parser import HTMLParser

UA = "Mozilla/5.0 (research-agent; student project)"


@dataclass
class Page:
    id: str
    url: str
    text: str


class _Text(HTMLParser):
    SKIP = {"script", "style", "noscript", "svg", "head"}

    def __init__(self):
        super().__init__()
        self.parts, self.depth = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.depth += 1

    def handle_endtag(self, tag):
        if tag in self.SKIP and self.depth:
            self.depth -= 1

    def handle_data(self, data):
        if not self.depth:
            self.parts.append(data)


def html_to_text(html: str) -> str:
    p = _Text()
    p.feed(html)
    return re.sub(r"\s+", " ", " ".join(p.parts)).strip()


def fetch(url: str, timeout: int = 15, max_bytes: int = 600_000) -> str:
    """Return page text, or raise on any failure."""
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read(max_bytes)
        charset = r.headers.get_content_charset() or "utf-8"
    return html_to_text(raw.decode(charset, errors="replace"))


def parse_ddg(html: str) -> list:
    urls = []
    for href in re.findall(r'class="result__a"[^>]*href="([^"]+)"', html):
        q = urllib.parse.urlparse(href).query
        target = urllib.parse.parse_qs(q).get("uddg", [href])[0]
        if target.startswith("http") and target not in urls:
            urls.append(target)
    return urls


def ddg_search(query: str, timeout: int = 15) -> list:
    url = "https://html.duckduckgo.com/html/?q=" + urllib.parse.quote(query)
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return parse_ddg(r.read().decode("utf-8", errors="replace"))


def gather(name, seed_urls, search_fn=ddg_search, fetch_fn=fetch, max_pages=6):
    """Collect up to max_pages readable pages. Returns (pages, notes).

    notes lists every search or fetch that failed, so the brief can say
    what the agent could not reach."""
    notes, urls = [], list(seed_urls)
    for q in (name, f"{name} about", f"{name} customers reviews"):
        if len(urls) >= max_pages * 2:
            break
        try:
            for u in search_fn(q):
                if u not in urls:
                    urls.append(u)
        except Exception as e:  # network, blocking, parsing
            notes.append(f"search failed for '{q}': {e}")
    pages = []
    for u in urls:
        if len(pages) >= max_pages:
            break
        try:
            text = fetch_fn(u)
        except Exception as e:
            notes.append(f"could not fetch {u}: {e}")
            continue
        if len(text) < 200:
            notes.append(f"{u}: too little text (likely needs JavaScript or a login)")
            continue
        pages.append(Page(f"S{len(pages) + 1}", u, text[:12000]))
    return pages, notes
