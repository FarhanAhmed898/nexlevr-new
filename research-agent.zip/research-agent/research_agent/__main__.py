import argparse
import sys

from .brief import ask_model, build, render
from .llm import AnthropicClient
from .sources import gather


def run(name, client, seed_urls=(), search_fn=None, fetch_fn=None, max_pages=6):
    kw = {k: v for k, v in (("search_fn", search_fn), ("fetch_fn", fetch_fn)) if v}
    pages, notes = gather(name, seed_urls, max_pages=max_pages, **kw)
    if not pages:
        raise SystemExit("No readable pages found, so no brief was written.\n" + "\n".join(notes))
    data = ask_model(client, name, pages)
    ok, bad, ideas = build(name, pages, data)
    return render(name, pages, ok, bad, ideas, notes)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="research_agent")
    ap.add_argument("business")
    ap.add_argument("--url", action="append", default=[], help="seed page (repeatable)")
    ap.add_argument("--out", help="write markdown here")
    a = ap.parse_args(argv)
    text = run(a.business, AnthropicClient(), a.url)
    if a.out:
        open(a.out, "w").write(text + "\n")
    print(text)


if __name__ == "__main__":
    sys.exit(main())
