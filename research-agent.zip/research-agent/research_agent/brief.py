"""Ask the model for claims with quotes, verify them in code, render the brief."""
import json
import re

SYSTEM = """You write a company brief using ONLY the numbered source pages given.
Return JSON only, in this shape:
{"sells":[C],"customers":[C],"online_presence":[C],
 "ideas":[{"idea":"...","why":"...","basis":"S1"}]}
where C = {"text":"one factual sentence","source":"S1","quote":"exact words copied from that page"}.
Rules: every claim needs a source id and a quote copied exactly from that page.
If the pages do not say it, leave it out. Do not guess. At most 3 claims per section
and exactly 3 ideas. Each idea's "basis" is the source id of the fact it builds on."""


def _norm(s):
    return re.sub(r"\s+", " ", re.sub(r"[‘’]", "'", re.sub(r"[“”]", '"', s))).strip().lower()


def verify_claim(claim, pages):
    """Return (ok, reason). A claim passes only if its quote is on its page."""
    page = next((p for p in pages if p.id == claim.get("source")), None)
    if page is None:
        return False, "cites a source that was not fetched"
    quote = _norm(str(claim.get("quote", "")))
    if len(quote) < 15:
        return False, "no usable quote"
    if quote not in _norm(page.text):
        return False, "quote not found on the cited page"
    claim_nums = set(re.findall(r"\d[\d,.]*", str(claim.get("text", ""))))
    if not all(n in quote or n in _norm(page.text) for n in claim_nums):
        return False, "a number in the claim is not on the page"
    return True, ""


def ask_model(client, name, pages):
    ctx = "\n\n".join(f"[{p.id}] {p.url}\n{p.text}" for p in pages)
    user = f"Company: {name}\n\nSources:\n{ctx}"
    last = ""
    for attempt in range(2):  # one retry on bad JSON
        raw = client.complete(SYSTEM, user if attempt == 0 else user + "\n\nReturn valid JSON only.")
        m = re.search(r"\{.*\}", raw, re.S)
        try:
            return json.loads(m.group(0))
        except (AttributeError, ValueError):
            last = raw[:200]
    raise ValueError(f"model did not return valid JSON: {last!r}")


def build(name, pages, data):
    """Split everything the model said into verified and unverified."""
    ok, bad, ideas = {"sells": [], "customers": [], "online_presence": []}, [], []
    for sec in ok:
        for c in data.get(sec, []) or []:
            good, why = verify_claim(c, pages)
            (ok[sec].append(c) if good else bad.append((sec, c.get("text", "?"), why)))
    for i in (data.get("ideas") or [])[:3]:
        good, why = verify_claim({"source": i.get("basis"), "quote": i.get("quote", ""), "text": ""}, pages) \
            if i.get("quote") else (any(p.id == i.get("basis") for p in pages), "basis source was not fetched")
        ideas.append((i, good, why))
    return ok, bad, ideas


def render(name, pages, ok, bad, ideas, notes):
    L = [f"# {name}: research brief", ""]
    titles = {"sells": "What they sell", "customers": "Who their customers are",
              "online_presence": "Online presence"}
    for sec, title in titles.items():
        L.append(f"## {title}")
        L += [f"- {c['text']} [{c['source']}]" for c in ok[sec]] or ["- Nothing verified from the sources found."]
        L.append("")
    L.append("## Three growth ideas (our suggestions, not facts)")
    for n, (i, good, _) in enumerate(ideas, 1):
        tag = f"[builds on {i.get('basis')}]" if good else "[basis not verified]"
        L.append(f"{n}. {i.get('idea', '?')}. {i.get('why', '')} {tag}")
    if not ideas:
        L.append("- No ideas could be tied to a fetched source.")
    L += ["", "## Could not verify"]
    flags = [f"- ({s}) {t}: {w}" for s, t, w in bad]
    flags += [f"- (idea) {i.get('idea', '?')}: {w}" for i, g, w in ideas if not g]
    flags += [f"- Run note: {n}" for n in notes]
    L += flags or ["- Nothing flagged. Every claim's quote was found on its source page."]
    L += ["", "## Sources"] + [f"- [{p.id}] {p.url}" for p in pages]
    return "\n".join(L)
