# Business research agent

Give it a business name. It searches public pages, fetches them, and writes a one-page
markdown brief: what they sell, who their customers are, online presence, three growth
ideas. Anything it could not verify is listed under **Could not verify**.

```
export ANTHROPIC_API_KEY=...
python3 -m research_agent "Business name" --out brief.md
python3 -m research_agent "Business name" --url https://their-site.com --url https://another-page
```
Standard library only, Python 3.9+. `RESEARCH_MODEL` overrides the model.

## How it works (and why it flags things)
1. **Gather** (`sources.py`): DuckDuckGo HTML search, plus any `--url` you give, then fetch up to 6 pages and strip them to text. Every failed search or fetch is recorded and printed in the brief.
2. **Extract** (`brief.py`): the model gets the numbered pages and must return JSON claims, each with a source id and an **exact quote** from that page.
3. **Verify in code, not by the model**: a claim passes only if its quote is found on the cited page (whitespace and curly quotes normalised) and any number in the claim also appears on the page. Failures move to *Could not verify* with the reason.
4. **Ideas** are labelled as suggestions, not facts, and tagged with the source they build on.
5. If no page can be read, it writes no brief and says why. Bad JSON from the model gets one retry.

## What was tested, honestly
- 12 offline tests pass (`python3 -m unittest discover -s tests -t .`): text extraction, search parsing, quote verification (good, fabricated, wrong source, invented number), retry, flagging, failed fetches, end to end.
- The model in tests is a scripted mock, not a language model. **It was never run against the live API or live search**, because the build sandbox had no API key and no web access. `examples/sample_brief.md` is a fixture run on a fictional company and only shows the format.
- Expect to adjust on first real run: DuckDuckGo may block or change its HTML (use `--url` to bypass); JavaScript-only sites yield little text and are skipped.

## Limits
- Verification proves a quote exists on a page, not that the page is right or current.
- A quote can be real but not support the claim; a person should skim the sources.
- Only 6 pages of 12,000 characters each are read. Paywalled and login pages are not.
