import unittest
from research_agent.sources import Page, html_to_text, parse_ddg, gather
from research_agent.brief import verify_claim, ask_model, build, render
from research_agent.llm import MockClient
from research_agent.__main__ import run

TEXT = ("Example Bakery is a family bakery in Sharjah. We sell sourdough bread, croissants and "
        "custom birthday cakes. Order online for delivery across Sharjah and Dubai. Follow us on Instagram. " * 3)
PAGES = [Page("S1", "https://example.test/a", TEXT)]


def claim(text, quote, src="S1"):
    return {"text": text, "source": src, "quote": quote}


class T(unittest.TestCase):
    def test_html_text_skips_scripts(self):
        self.assertEqual(html_to_text("<p>Hi</p><script>x=1</script><b>there</b>"), "Hi there")

    def test_parse_ddg(self):
        h = '<a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fa.test%2Fx&rut=1">A</a>'
        self.assertEqual(parse_ddg(h), ["https://a.test/x"])

    def test_good_quote_passes_even_with_odd_spacing(self):
        ok, _ = verify_claim(claim("Sells sourdough", "we sell  sourdough bread,\n croissants"), PAGES)
        self.assertTrue(ok)

    def test_fabricated_quote_fails(self):
        ok, why = verify_claim(claim("Has 40 stores", "operates forty stores across the UAE"), PAGES)
        self.assertFalse(ok); self.assertIn("not found", why)

    def test_unknown_source_fails(self):
        ok, why = verify_claim(claim("x", "family bakery in Sharjah", "S9"), PAGES)
        self.assertFalse(ok); self.assertIn("not fetched", why)

    def test_invented_number_fails(self):
        ok, why = verify_claim(claim("Founded in 1985", "family bakery in Sharjah"), PAGES)
        self.assertFalse(ok); self.assertIn("number", why)

    def test_short_quote_fails(self):
        self.assertFalse(verify_claim(claim("x", "bakery"), PAGES)[0])

    def test_bad_json_retries_once_then_raises(self):
        with self.assertRaises(ValueError):
            ask_model(MockClient(["nope", "still nope"]), "X", PAGES)
        self.assertEqual(ask_model(MockClient(["nope", '{"sells":[]}']), "X", PAGES), {"sells": []})

    def test_unverified_goes_to_flag_section(self):
        data = {"sells": [claim("Sells bread", "We sell sourdough bread"), claim("Has 40 stores", "forty stores everywhere")],
                "customers": [], "online_presence": [],
                "ideas": [{"idea": "Subscription box", "why": "repeat orders", "basis": "S1"},
                          {"idea": "Wholesale", "why": "cafes", "basis": "S7"}]}
        ok, bad, ideas = build("Example Bakery", PAGES, data)
        md = render("Example Bakery", PAGES, ok, bad, ideas, ["search failed for 'x': 403"])
        self.assertIn("Sells bread [S1]", md)
        self.assertNotIn("40 stores [S1]", md)
        self.assertIn("Has 40 stores", md.split("## Could not verify")[1])
        self.assertIn("[basis not verified]", md)
        self.assertIn("Run note: search failed", md)
        self.assertIn("Nothing verified", md)  # empty sections say so

    def test_gather_records_failures(self):
        def bad_search(q): raise OSError("blocked")
        def fetch(u): return TEXT if "good" in u else ""
        pages, notes = gather("X", ["https://good.test", "https://empty.test"], bad_search, fetch)
        self.assertEqual(len(pages), 1)
        self.assertTrue(any("search failed" in n for n in notes))
        self.assertTrue(any("too little text" in n for n in notes))

    def test_no_pages_means_no_brief(self):
        with self.assertRaises(SystemExit):
            run("X", MockClient([]), [], lambda q: [], lambda u: "")

    def test_end_to_end_with_mock(self):
        import json
        reply = json.dumps({"sells": [claim("Sells sourdough and croissants", "sourdough bread, croissants")],
                            "customers": [], "online_presence": [claim("Delivers online", "Order online for delivery")],
                            "ideas": [{"idea": "Corporate breakfast boxes", "why": "offices in Dubai", "basis": "S1"}]})
        md = run("Example Bakery", MockClient([reply]), ["https://example.test/a"], lambda q: [], lambda u: TEXT)
        self.assertIn("Delivers online [S1]", md)
        self.assertIn("## Sources", md)


if __name__ == "__main__":
    unittest.main()
