import copy
import io
import json
import tempfile
import threading
import unittest
from contextlib import redirect_stdout
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

from digest import __main__ as cli
from digest.feeds import load_all, parse_feed, select
from digest.llm import AnthropicClient, MockClient
from digest.write import build_prompt, extractive_digest, render, validate, write_digest

FX = Path(__file__).parent / "fixtures"
NOW = datetime(2026, 11, 15, 12, 0, tzinfo=timezone.utc)
CFG = json.loads((Path(__file__).parent.parent / "config.json").read_text())
FEEDS = [{"name": "A", "url": "a"}, {"name": "B", "url": "b"}, {"name": "G", "url": "g", "filter": True}]
FILES = {"a": "rss_a.xml", "b": "atom_b.xml", "g": "rss_general.xml"}


def fake_fetch(url): return (FX / FILES[url]).read_bytes()


def candidates():
    return select(load_all(FEEDS, fetch=fake_fetch, log=lambda *_: None), CFG, now=NOW)


class Parse(unittest.TestCase):
    def test_rss_html_cleaned(self):
        items = parse_feed((FX / "rss_a.xml").read_bytes(), "A")
        self.assertEqual(len(items), 5)
        self.assertEqual(items[0].summary, "Most people stall because the plan is too big. Start with 10 minutes a day & build.")
        self.assertEqual(items[0].published.year, 2026)

    def test_atom(self):
        items = parse_feed((FX / "atom_b.xml").read_bytes(), "B")
        self.assertEqual([i.link for i in items][:2], ["https://b.example/isometric", "https://b.example/5k"])
        self.assertIsNotNone(items[1].published)

    def test_undated_item_has_none(self):
        self.assertIsNone(parse_feed((FX / "rss_general.xml").read_bytes(), "G")[2].published)


class Select(unittest.TestCase):
    def test_off_topic_dropped_from_general_feed_only(self):
        titles = [i.title for i in candidates()]
        self.assertNotIn("Bowen Yang returned to SNL", titles)
        self.assertIn("Best gym workout for busy people", titles)

    def test_old_item_dropped_in_normal_window(self):
        self.assertNotIn("Old post about running", [i.title for i in candidates()])

    def test_duplicate_title_removed(self):
        links = [i.link for i in candidates()]
        self.assertIn("https://a.example/get-back", links); self.assertNotIn("https://b.example/dup", links)

    def test_undated_kept(self):
        self.assertIn("https://g.example/sleep-nutrition", [i.link for i in candidates()])

    def test_ids_numbered_from_1(self):
        self.assertEqual([i.id for i in candidates()], list(range(1, len(candidates()) + 1)))

    def test_quiet_week_widens_window(self):
        cfg = copy.deepcopy(CFG); cfg["lookback_days"] = 1
        titles = [i.title for i in select(load_all(FEEDS, fetch=fake_fetch, log=lambda *_: None), cfg, now=NOW)]
        self.assertGreaterEqual(len(titles), 5)                      # window widened rather than returning 2 stories
        self.assertIn("Sleep and recovery: why 7 hours matters", titles)  # 4 days old: outside 1 day, inside 30
        self.assertNotIn("Old post about running", titles)           # 75 days old: outside even the widened window

    def test_one_dead_feed_does_not_stop_the_rest(self):
        def flaky(url):
            if url == "b": raise OSError("boom")
            return fake_fetch(url)
        logs = []
        items = load_all(FEEDS, fetch=flaky, log=logs.append)
        self.assertTrue(any("skipped B" in l for l in logs)); self.assertTrue(items)


class Validate(unittest.TestCase):
    def good(self, ids=(1, 2, 3, 4, 5)):
        items = candidates()
        return items, json.dumps({"bullets": [{"headline": f"h{i}", "what_happened": "A short fact.", "post_idea": "Reel: a hook.", "source_id": i} for i in ids]})

    def test_good(self):
        items, r = self.good(); b, p = validate(r, items); self.assertEqual(p, []); self.assertEqual(len(b), 5)
    def test_fence(self): self.assertIn("fence", validate("```json\n{}\n```", candidates())[1][0])
    def test_not_json(self): self.assertIn("not valid JSON", validate("Sure!", candidates())[1][0])
    def test_four_bullets(self):
        items, r = self.good(); d = json.loads(r); d["bullets"].pop(); self.assertTrue(any("exactly 5" in p for p in validate(json.dumps(d), items)[1]))
    def test_unknown_source(self):
        items, r = self.good((1, 2, 3, 4, 99)); self.assertTrue(any("99" in p for p in validate(r, items)[1]))
    def test_repeated_source(self):
        items, r = self.good((1, 1, 2, 3, 4)); self.assertTrue(any("different story" in p for p in validate(r, items)[1]))
    def test_extra_key_such_as_link(self):
        items, r = self.good(); d = json.loads(r); d["bullets"][0]["link"] = "http://evil"; self.assertTrue(validate(json.dumps(d), items)[1])
    def test_invented_number(self):
        items, r = self.good(); d = json.loads(r); d["bullets"][0]["what_happened"] = "A study found 87 percent improved."
        self.assertTrue(any("not in story" in p for p in validate(json.dumps(d), items)[1]))
    def test_number_from_story_is_allowed(self):
        items = candidates(); protein = next(i for i in items if "protein" in i.title.lower())
        d = {"bullets": [{"headline": "h", "what_happened": "Target is 1.6 g per kg.", "post_idea": "x", "source_id": protein.id}] + [
            {"headline": "h", "what_happened": "Fact.", "post_idea": "x", "source_id": i.id} for i in items if i.id != protein.id][:4]}
        self.assertEqual(validate(json.dumps(d), items)[1], [])


class Writer(unittest.TestCase):
    def test_mock_is_valid(self):
        items = candidates(); self.assertEqual(len(write_digest(items, CFG, MockClient(), log=lambda *_: None)), 5)

    def test_retry_feeds_problems_back(self):
        items, prompts = candidates(), []
        class Bad:
            n = 0
            def generate(self, p):
                prompts.append(p); Bad.n += 1
                return "```json\n{}\n```" if Bad.n == 1 else MockClient().generate(p)
        write_digest(items, CFG, Bad(), log=lambda *_: None)
        self.assertIn("REJECTED", prompts[1]); self.assertIn("code fence", prompts[1]); self.assertNotIn("REJECTED", prompts[0])

    def test_gives_up(self):
        class Never:
            def generate(self, p): return "nope"
        with self.assertRaises(RuntimeError): write_digest(candidates(), CFG, Never(), max_attempts=2, log=lambda *_: None)

    def test_api_error_counts_as_attempt(self):
        class Boom:
            n = 0
            def generate(self, p):
                Boom.n += 1
                if Boom.n == 1: raise RuntimeError("API error 529")
                return MockClient().generate(p)
        self.assertEqual(len(write_digest(candidates(), CFG, Boom(), log=lambda *_: None)), 5)

    def test_link_comes_from_feed_not_model(self):
        items = candidates(); b = write_digest(items, CFG, MockClient(), log=lambda *_: None)
        text = render(b, items, CFG)
        self.assertIn(items[0].link, text); self.assertEqual(text.count("Source: ["), 5)

    def test_extractive_fallback(self):
        items = candidates(); b = extractive_digest(items); self.assertEqual(len(b), 5)
        self.assertIn("without a language model", render(b, items, CFG, mode="extractive"))

    def test_prompt_lists_numbered_stories(self):
        p = build_prompt(candidates(), CFG); self.assertIn("[1] ", p); self.assertIn("exactly these keys", p)


class EndToEnd(unittest.TestCase):
    def run_cli(self, *flags):
        with tempfile.TemporaryDirectory() as d, redirect_stdout(io.StringIO()) as out:
            # route the three fixture feeds through a temporary config
            cfg = dict(CFG, feeds=FEEDS, lookback_days=3650)
            Path(d, "c.json").write_text(json.dumps(cfg))
            code = cli.main(["--config", str(Path(d, "c.json")), "--out", d, *flags], fetch=fake_fetch)
            files = list(Path(d).glob("*.md")); return code, out.getvalue(), files and files[0].read_text()

    def test_mock(self):
        code, out, md = self.run_cli("--mock"); self.assertEqual(code, 0); self.assertEqual(md.count("Post idea:"), 5)
    def test_no_llm(self):
        code, out, md = self.run_cli("--no-llm"); self.assertEqual(code, 0); self.assertIn("without a language model", md)


class Backend(unittest.TestCase):
    def test_request_shape(self):
        got = {}
        class H(BaseHTTPRequestHandler):
            def do_POST(self):
                got["body"] = json.loads(self.rfile.read(int(self.headers["content-length"]))); got["key"] = self.headers["x-api-key"]
                out = json.dumps({"content": [{"type": "text", "text": "hi"}]}).encode()
                self.send_response(200); self.send_header("content-length", str(len(out))); self.end_headers(); self.wfile.write(out)
            def log_message(self, *a): pass
        srv = HTTPServer(("127.0.0.1", 0), H); threading.Thread(target=srv.handle_request, daemon=True).start()
        import os; os.environ["ANTHROPIC_API_KEY"] = "k"; os.environ["ANTHROPIC_BASE_URL"] = f"http://127.0.0.1:{srv.server_port}"
        self.assertEqual(AnthropicClient().generate("p"), "hi"); srv.server_close(); self.assertEqual(got["key"], "k"); self.assertEqual(got["body"]["messages"][0]["content"], "p")
    def test_missing_key(self):
        import os; os.environ.pop("ANTHROPIC_API_KEY", None)
        with self.assertRaises(RuntimeError): AnthropicClient().generate("p")


if __name__ == "__main__":
    unittest.main()
