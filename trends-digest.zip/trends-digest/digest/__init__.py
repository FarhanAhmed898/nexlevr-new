"""Daily trends digest agent: read RSS feeds, pick stories, write a 5-bullet digest with post ideas."""
