"""Step 3: ask the model for the digest as JSON, validate it, retry with the problems fed back, render markdown."""
from __future__ import annotations

import json
import re
from datetime import date

from .feeds import Item

PROMPT = """You write a daily news digest for the social media manager of {brand}.
Industry: {industry}. Below are today's candidate stories, numbered. Choose the 5 most useful for the brand to post about.

RULES
1. Reply with one JSON object only, no markdown fences: {{"bullets": [5 objects]}}.
2. Each bullet object has exactly these keys:
   "headline": under 12 words,
   "what_happened": 1 or 2 sentences, under 45 words, using only facts in that story's title or summary,
   "post_idea": one concrete idea for the brand: the format (Reel, carousel, story, photo post) and the hook, under 40 words,
   "source_id": the number of the story it comes from.
3. Use 5 different stories. Never invent a number, name, quote or study result that is not in the story text.
4. Do not give medical advice or promise results. Post ideas should invite people to move, learn or ask a coach.

STORIES
{stories}
"""
RETRY = "\n\nYOUR PREVIOUS REPLY WAS REJECTED. Problems:\n{problems}\n\nPrevious reply:\n{previous}\n\nReply again with the corrected JSON object only."


def build_prompt(items: list[Item], cfg: dict, previous: str | None = None, problems: list[str] | None = None) -> str:
    stories = "\n".join(f"[{i.id}] {i.source} | {i.title} | {i.published.date() if i.published else 'undated'} | {i.summary}" for i in items)
    text = PROMPT.format(brand=cfg["brand"], industry=cfg["industry"], stories=stories)
    if previous is not None and problems:
        text += RETRY.format(problems="\n".join(f"- {p}" for p in problems), previous=previous[:1500])
    return text


def _numbers(s: str) -> set[str]:
    return set(re.findall(r"\d+(?:\.\d+)?", s.replace(",", "")))


def validate(reply: str, items: list[Item]) -> tuple[list[dict] | None, list[str]]:
    if reply.strip().startswith("```"):
        return None, ["reply is wrapped in a code fence; reply with raw JSON only"]
    try:
        data = json.loads(reply)
    except json.JSONDecodeError as e:
        return None, [f"reply is not valid JSON ({e.msg}); reply with the JSON object only"]
    bullets = data.get("bullets") if isinstance(data, dict) else None
    if not isinstance(bullets, list):
        return None, ['reply must be {"bullets": [...]}']
    by_id = {i.id: i for i in items}
    problems: list[str] = []
    if len(bullets) != 5:
        problems.append(f"need exactly 5 bullets, got {len(bullets)}")
    used: list = []
    for n, b in enumerate(bullets, 1):
        if not isinstance(b, dict) or set(b) != {"headline", "what_happened", "post_idea", "source_id"}:
            problems.append(f"bullet {n}: must have exactly the keys headline, what_happened, post_idea, source_id"); continue
        if not all(isinstance(b[k], str) and b[k].strip() for k in ("headline", "what_happened", "post_idea")):
            problems.append(f"bullet {n}: headline, what_happened and post_idea must be non-empty strings"); continue
        sid = b["source_id"]
        if sid not in by_id:
            problems.append(f"bullet {n}: source_id {sid!r} is not one of the numbered stories"); continue
        used.append(sid)
        if len(b["headline"].split()) > 12: problems.append(f"bullet {n}: headline over 12 words")
        if len(b["what_happened"].split()) > 45: problems.append(f"bullet {n}: what_happened over 45 words")
        if len(b["post_idea"].split()) > 40: problems.append(f"bullet {n}: post_idea over 40 words")
        src = by_id[sid]
        invented = _numbers(b["what_happened"]) - _numbers(f"{src.title} {src.summary}")
        if invented:
            problems.append(f"bullet {n}: numbers {sorted(invented)} are not in story {sid}")
    if len(set(used)) != len(used):
        problems.append("each bullet must use a different story")
    return (bullets if not problems else None), problems


def write_digest(items: list[Item], cfg: dict, client, max_attempts: int = 3, log=print) -> list[dict]:
    previous, problems = None, None
    for attempt in range(1, max_attempts + 1):
        try:
            reply = client.generate(build_prompt(items, cfg, previous, problems))
        except Exception as exc:
            problems, previous = [f"model call failed: {exc}"], ""
            log(f"  attempt {attempt}: {problems[0]}"); continue
        bullets, problems = validate(reply, items)
        if bullets:
            return bullets
        log(f"  attempt {attempt} rejected: {'; '.join(problems)}")
        previous = reply
    raise RuntimeError("the model did not produce a valid digest: " + "; ".join(problems or []))


def extractive_digest(items: list[Item]) -> list[dict]:
    """No-model fallback: the 5 top-ranked stories, with a plain template for the post idea."""
    return [{"headline": i.title, "what_happened": i.summary or "(no summary in the feed)",
             "post_idea": "Share this with your take in one line and ask followers what they think.", "source_id": i.id}
            for i in items[:5]]


def render(bullets: list[dict], items: list[Item], cfg: dict, today: date | None = None, mode: str = "model") -> str:
    by_id = {i.id: i for i in items}
    today = today or date.today()
    lines = [f"# {cfg['industry'].title()} trends digest, {today.isoformat()}", ""]
    for n, b in enumerate(bullets, 1):
        src = by_id[b["source_id"]]  # the link always comes from the feed, never from the model
        lines += [f"{n}. **{b['headline']}**  ", f"   {b['what_happened']}  ",
                  f"   *Post idea:* {b['post_idea']}  ", f"   Source: [{src.source}]({src.link})", ""]
    if mode != "model":
        lines += ["_Written without a language model: summaries are copied from the feeds._", ""]
    return "\n".join(lines)
