"""Model clients: the real Anthropic API, and an offline mock for tests and demos."""
from __future__ import annotations

import json
import os
import re
import time
import urllib.error
import urllib.request


class AnthropicClient:
    """Needs ANTHROPIC_API_KEY. Not run against the live API in this repo's tests."""

    def __init__(self, model: str = "claude-haiku-5-5", max_tokens: int = 1800):
        self.model, self.max_tokens = model, max_tokens
        self.key = os.environ.get("ANTHROPIC_API_KEY", "")
        self.base = os.environ.get("ANTHROPIC_BASE_URL", "https://api.anthropic.com").rstrip("/")

    def generate(self, prompt: str) -> str:
        if not self.key:
            raise RuntimeError("ANTHROPIC_API_KEY is not set (use --mock or --no-llm to run without it)")
        body = json.dumps({"model": self.model, "max_tokens": self.max_tokens, "temperature": 0.4,
                           "messages": [{"role": "user", "content": prompt}]}).encode()
        req = urllib.request.Request(f"{self.base}/v1/messages", data=body, headers={
            "x-api-key": self.key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
        for attempt in range(4):
            try:
                with urllib.request.urlopen(req, timeout=120) as r:
                    data = json.load(r)
                return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
            except urllib.error.HTTPError as e:
                if e.code in (429, 500, 502, 503, 529) and attempt < 3:
                    time.sleep(2 ** attempt)
                    continue
                raise RuntimeError(f"API error {e.code}: {e.read().decode()[:300]}") from e


class MockClient:
    """Offline stand-in. It reads the numbered candidates out of the prompt and builds a valid reply from the
    first five. It is NOT a language model: its 'post ideas' are fixed templates."""

    def generate(self, prompt: str) -> str:
        found = re.findall(r"^\[(\d+)\] (.+?) \| (.+?) \| ", prompt, re.M)[:5]
        ideas = ["Carousel: 3 takeaways, one per slide", "Reel: 20-second explainer with on-screen text",
                 "Story poll: ask followers which tip they will try", "Photo post: a coach's one-line opinion",
                 "Checklist graphic: save and share"]
        bullets = [{"headline": title[:70], "what_happened": f"{src} reports: {title}.", "post_idea": ideas[n % 5], "source_id": int(i)}
                   for n, (i, src, title) in enumerate(found)]
        return json.dumps({"bullets": bullets})
