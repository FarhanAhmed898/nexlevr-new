"""python -m digest [--mock | --no-llm] [--config config.json] [--out digests]"""
import argparse
import json
import sys
from datetime import date
from pathlib import Path

from .feeds import load_all, select
from .llm import AnthropicClient, MockClient
from .write import extractive_digest, render, write_digest


def main(argv=None, fetch=None) -> int:
    ap = argparse.ArgumentParser(prog="digest", description="Write today's 5-bullet trends digest.")
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--out", default="digests", help="folder for the dated markdown file")
    ap.add_argument("--model", default="claude-haiku-5-5")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--mock", action="store_true", help="offline mock model (templates, not a language model)")
    g.add_argument("--no-llm", action="store_true", help="no model: copy the top 5 stories from the feeds")
    a = ap.parse_args(argv)
    cfg = json.loads(Path(a.config).read_text())
    print("Reading feeds:")
    kw = {"fetch": fetch} if fetch else {}
    items = select(load_all(cfg["feeds"], **kw), cfg)
    if len(items) < 5:
        print(f"Only {len(items)} usable stories found; need at least 5. Nothing written.", file=sys.stderr)
        return 1
    mode = "extractive" if a.no_llm else "model"
    bullets = extractive_digest(items) if a.no_llm else write_digest(items, cfg, MockClient() if a.mock else AnthropicClient(a.model))
    text = render(bullets, items, cfg, mode=mode)
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    path = out / f"{date.today().isoformat()}.md"
    path.write_text(text, encoding="utf-8")
    print(text); print(f"Saved to {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
