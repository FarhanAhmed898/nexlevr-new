"""Step 1 and 2: fetch feeds, parse RSS 2.0 and Atom, clean, filter, rank. Standard library only."""
from __future__ import annotations

import html
import re
import urllib.request
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime

UA = "trends-digest/1.0 (+personal project)"
ATOM = "{http://www.w3.org/2005/Atom}"


@dataclass
class Item:
    id: int
    source: str
    title: str
    link: str
    summary: str
    published: datetime | None
    needs_keywords: bool = False  # general-interest feed: keep only on-topic stories


def http_fetch(url: str, timeout: int = 20) -> bytes:
    if not url.startswith(("http://", "https://")):  # a local file path: used by the offline demo
        from pathlib import Path
        return Path(url).read_bytes()
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/rss+xml, application/atom+xml, application/xml, text/xml"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def clean(text: str | None, limit: int = 400) -> str:
    text = html.unescape(re.sub(r"<[^>]+>", " ", text or ""))
    text = re.sub(r"\s+", " ", text).strip()
    return text if len(text) <= limit else text[:limit].rsplit(" ", 1)[0] + "..."


def parse_date(raw: str | None) -> datetime | None:
    if not raw:
        return None
    raw = raw.strip()
    try:
        d = parsedate_to_datetime(raw)  # RSS: "Thu, 22 Oct 2026 09:56:24 +0000"
    except (TypeError, ValueError):
        try:
            d = datetime.fromisoformat(raw.replace("Z", "+00:00"))  # Atom: ISO 8601
        except ValueError:
            return None
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def parse_feed(xml_bytes: bytes, source: str) -> list[Item]:
    root = ET.fromstring(xml_bytes)
    items: list[Item] = []
    if root.tag == f"{ATOM}feed":
        for e in root.findall(f"{ATOM}entry"):
            link = next((l.get("href") for l in e.findall(f"{ATOM}link") if l.get("rel") in (None, "alternate")), "")
            items.append(Item(0, source, clean(e.findtext(f"{ATOM}title"), 200), (link or "").strip(),
                              clean(e.findtext(f"{ATOM}summary") or e.findtext(f"{ATOM}content")),
                              parse_date(e.findtext(f"{ATOM}published") or e.findtext(f"{ATOM}updated"))))
    else:
        for e in root.iter("item"):
            items.append(Item(0, source, clean(e.findtext("title"), 200), (e.findtext("link") or "").strip(),
                              clean(e.findtext("description")), parse_date(e.findtext("pubDate"))))
    return [i for i in items if i.title and i.link.startswith("http")]


def load_all(feeds: list[dict], fetch=http_fetch, log=print) -> list[Item]:
    """One broken feed must never stop the digest: log it and carry on."""
    out: list[Item] = []
    for f in feeds:
        try:
            got = parse_feed(fetch(f["url"]), f["name"])
        except Exception as exc:
            log(f"  skipped {f['name']}: {type(exc).__name__}: {exc}")
            continue
        log(f"  {f['name']}: {len(got)} items")
        for i in got:
            i.needs_keywords = bool(f.get("filter"))
        out += got
    return out


def select(items: list[Item], cfg: dict, now: datetime | None = None) -> list[Item]:
    """Keyword filter (for general feeds), freshness window, de-duplicate, rank, number the survivors."""
    now = now or datetime.now(timezone.utc)
    kws = [k.lower() for k in cfg["keywords"]]

    def hits(i: Item) -> int:
        blob = f"{i.title} {i.summary}".lower()
        return sum(1 for k in kws if re.search(rf"\b{re.escape(k)}", blob))

    pool = [i for i in items if not getattr(i, "needs_keywords", False) or hits(i) > 0]

    def fresh(days: int) -> list[Item]:
        cutoff = now - timedelta(days=days)
        return [i for i in pool if i.published is None or i.published >= cutoff]

    chosen = fresh(cfg["lookback_days"])
    if len(chosen) < 5:  # quiet week: widen the window rather than return fewer than 5 stories
        chosen = fresh(cfg["widen_to_days"])
    seen_links, seen_titles, unique = set(), set(), []
    for i in chosen:
        key = re.sub(r"\W+", " ", i.title.lower()).strip()
        if i.link in seen_links or key in seen_titles:
            continue
        seen_links.add(i.link); seen_titles.add(key); unique.append(i)

    def score(i: Item) -> float:
        age_days = (now - i.published).total_seconds() / 86400 if i.published else 3.0  # undated: treated as 3 days old
        return hits(i) * 1.0 - age_days * 0.3

    unique.sort(key=score, reverse=True)
    top = unique[: cfg["max_candidates"]]
    for n, i in enumerate(top, 1):
        i.id = n
    return top
