# Daily trends digest agent

Reads 5 RSS feeds for an industry (set up for **fitness**), picks the 5 most useful stories, and writes a **5-bullet digest** where every bullet has a source link and a post idea a brand could use. Standard library only.

```bash
python -m digest --mock --config demo_config.json     # offline demo on sample feeds, no key needed
export ANTHROPIC_API_KEY=...
python -m digest                                      # real feeds + real model, saves digests/YYYY-MM-DD.md
python -m digest --no-llm                             # real feeds, no model: copies the top 5 stories
python -m unittest discover -s tests -t .             # 30 offline tests
```

## How it works

```
5 feeds --fetch--> parse (RSS 2.0 + Atom) --> clean HTML --> filter off-topic --> fresh only --> de-duplicate --> rank --> numbered candidates
candidates --> model writes JSON (5 bullets) --> validate --> retry with the problems fed back (3 tries) --> render markdown
```

1. **Fetch and parse** (`digest/feeds.py`). Handles RSS and Atom. One dead feed is logged and skipped, it never stops the run.
2. **Select.** General-interest feeds (marked `"filter": true`) keep only stories that mention a fitness keyword. Stories older than `lookback_days` (7) are dropped; if fewer than 5 remain, the window widens to 30 days. Duplicate stories across feeds are removed. Stories are ranked by keyword hits and recency, and numbered.
3. **Write** (`digest/write.py`). The model gets the numbered stories and must return JSON with exactly 5 bullets: `headline`, `what_happened`, `post_idea`, `source_id`.
4. **Validate.** Exactly 5 bullets, 5 different stories, a real `source_id`, length limits, no extra keys, and **no number in `what_happened` that is not in that story's title or summary**. A rejected reply is sent back with the exact problems, up to 3 attempts.
5. **Render.** The link under each bullet is looked up from the feed by `source_id`, so the model can never invent or alter a link.

## Sample output

From `python -m digest --mock --config demo_config.json`. The mock is a script that fills fixed templates, so the post ideas here are placeholders. A real model writes real ones.

```
# Fitness trends digest, 2026-11-15

1. **Best gym workout for busy people**
   Sample general feed reports: Best gym workout for busy people.
   *Post idea:* Carousel: 3 takeaways, one per slide
   Source: [Sample general feed](https://g.example/gym)
...
```

## The feeds in `config.json`

Checked on 15 November 2026 by opening each one:

| Feed | Result |
| --- | --- |
| Nerd Fitness | Valid RSS, newest item 22 Oct 2026 |
| Stronger by Science | Valid RSS, newest item seen 11 Jun 2026 (posts rarely) |
| Healthline News | Valid RSS, updated 14 Nov 2026, items have no dates (the agent treats them as 3 days old) |
| Men's Journal | Valid RSS, updated daily, mostly general news, so it is keyword-filtered |
| Breaking Muscle | Valid RSS, but the newest items I saw were from 2023, so it may be inactive. Swap it if it stays empty |

Runner's World blocked the check, and T-Nation and BarBend did not return usable feeds. Edit `config.json` to change feeds, keywords, brand description or industry.

## Run it every day

`.github/workflows/daily-digest.yml` runs the tests and the digest every day at 07:00 Dubai time, and saves the digest as a downloadable file on the run. Add your key as a repository secret named `ANTHROPIC_API_KEY`. Or use cron: `0 7 * * * cd /path/to/trends-digest && python -m digest`.

## Limits

- **Not run end to end on live feeds or the live API.** The sandbox I built this in cannot reach the feeds (all five were refused) or the API. The parsers are tested on sample RSS and Atom files, and the Anthropic client against a local fake server. Run `python -m digest --no-llm` first to check the feeds from your machine.
- The demo feeds are dated November 2026. Run the demo much later and it will report too few stories; raise `lookback_days` in `demo_config.json`.
- The number check catches invented numbers, not invented claims in words. Skim the digest before posting.
- Post ideas are suggestions. Do not post health claims without checking the source.
