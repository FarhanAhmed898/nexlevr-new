"""extract(): prompt -> parse -> validate -> retry with the problems fed back."""
from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field

from .prompt import build_prompt
from .validate import parse_json, validate


class AnthropicModel:
    """Real backend (needs ANTHROPIC_API_KEY). Not exercised against the live API in this repo's tests."""

    def __init__(self, model_id="claude-haiku-5-5", max_tokens=700):
        self.model_id, self.max_tokens = model_id, max_tokens
        self.key = os.environ.get("ANTHROPIC_API_KEY", "")
        self.base = os.environ.get("ANTHROPIC_BASE_URL", "https://api.anthropic.com").rstrip("/")

    def generate(self, prompt: str) -> str:
        if not self.key:
            raise RuntimeError("ANTHROPIC_API_KEY is not set")
        body = json.dumps({"model": self.model_id, "max_tokens": self.max_tokens, "temperature": 0,
                           "messages": [{"role": "user", "content": prompt}]}).encode()
        req = urllib.request.Request(f"{self.base}/v1/messages", data=body, headers={
            "x-api-key": self.key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
        for attempt in range(4):
            try:
                with urllib.request.urlopen(req, timeout=120) as r:
                    data = json.load(r)
                return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
            except urllib.error.HTTPError as e:
                if e.code in (429, 500, 502, 503, 529) and attempt < 3:
                    time.sleep(2 ** attempt)
                    continue
                raise RuntimeError(f"API error {e.code}") from e


@dataclass
class Result:
    ok: bool
    data: dict | None
    attempts: int
    history: list = field(default_factory=list)  # one {"reply", "problems"} per attempt
    needs_review: list = field(default_factory=list)


def extract(raw: str, model, max_attempts: int = 3) -> Result:
    previous, problems, history = None, None, []
    for attempt in range(1, max_attempts + 1):
        try:
            reply = model.generate(build_prompt(raw, previous, problems))
        except Exception as e:  # network/API failure counts as a failed attempt
            problems, previous = [f"model call failed: {e}"], ""
            history.append({"reply": "", "problems": problems})
            continue
        obj, problem = parse_json(reply)
        problems = [problem] if problem else validate(obj, raw)
        history.append({"reply": reply, "problems": problems})
        if not problems:
            return Result(True, obj, attempt, history, obj["needs_review"])
        previous = reply
    return Result(False, None, max_attempts, history)
