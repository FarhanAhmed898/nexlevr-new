"""The extraction prompt. Retries append the validator's error list so the model can fix exactly what failed."""

SYSTEM = """You turn messy product information into ONE JSON object for a website catalogue.
The input may be supplier notes, text read from photos (OCR, so it can contain typos), or spreadsheet rows.

OUTPUT RULES
1. Reply with the JSON object only. No markdown fences, no commentary.
2. Use exactly these keys and no others:
   {
     "name": string, 3-80 characters, the product name only (no price, size or SKU),
     "price": {"amount": number, "currency": "AED"} or null,
     "sizes": array of strings, [] if the product has no sizes,
     "features": array of 1-8 short strings (max 80 characters each),
     "description": string of 20-60 words, plain sentences, no exclamation marks,
     "needs_review": array of strings naming any field you could not fill from the input
   }
3. Use ONLY facts in the input. Never guess or invent a price, size, material or claim.
   If the price is missing or unclear, set "price" to null and add "price" to "needs_review".
   If no feature is stated, write one feature from the product name and add "features" to "needs_review".
4. Price: the number as written, with a dot for decimals (1,299.50 -> 1299.5). Currency is a 3-letter code
   (Dhs, AED, dirham -> AED; $ -> USD; EUR/euro -> EUR). If several prices appear (old and sale), use the current one
   and add "price" to "needs_review" only if you cannot tell which is current.
5. Sizes: keep the supplier's labels (S, M, 42, 10 oz), each once, in a sensible order.
6. Features are short noun phrases, one idea each, no duplicates.
7. The description is written for a shopper, uses only the stated facts, and never contains hype words
   (best, perfect, amazing, unbeatable, revolutionary).
8. If the input is not about a single product (several products, or nothing usable), return
   {"name": "", "price": null, "sizes": [], "features": [], "description": "", "needs_review": ["not a single product"]}.

INPUT
<<<
{raw}
>>>"""

RETRY = """

YOUR PREVIOUS REPLY WAS REJECTED. Problems found:
{problems}

Previous reply:
{previous}

Reply again with the corrected JSON object only."""


def build_prompt(raw: str, previous: str | None = None, problems: list[str] | None = None) -> str:
    text = SYSTEM.replace("{raw}", raw.strip())
    if previous is not None and problems:
        text += RETRY.replace("{problems}", "\n".join(f"- {p}" for p in problems)).replace("{previous}", previous[:1500])
    return text
