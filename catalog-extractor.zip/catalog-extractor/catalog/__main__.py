"""python -m catalog input.txt [--model claude-haiku-5-5]  -> prints JSON, exit 0 ok, 1 failed (needs a human)."""
import argparse
import json
import sys

from .extract import AnthropicModel, extract

ap = argparse.ArgumentParser()
ap.add_argument("input")
ap.add_argument("--model", default="claude-haiku-5-5")
ap.add_argument("--attempts", type=int, default=3)
a = ap.parse_args()
res = extract(open(a.input, encoding="utf-8").read(), AnthropicModel(a.model), a.attempts)
if res.ok:
    print(json.dumps(res.data, indent=2, ensure_ascii=False))
    sys.exit(0)
print(json.dumps({"failed": True, "attempts": res.attempts, "last_problems": res.history[-1]["problems"]}, indent=2), file=sys.stderr)
sys.exit(1)
