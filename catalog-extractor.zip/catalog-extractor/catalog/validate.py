"""Schema validation + grounding checks. Returns a list of problems; an empty list means valid."""
from __future__ import annotations

import json
import re

KEYS = {"name", "price", "sizes", "features", "description", "needs_review"}
HYPE = ("best", "perfect", "amazing", "unbeatable", "revolutionary")
CURRENCY = re.compile(r"^[A-Z]{3}$")


def parse_json(reply: str):
    """Strict parse. Returns (obj, problem). Markdown fences are rejected, not silently repaired."""
    text = reply.strip()
    if text.startswith("```"):
        return None, "reply is wrapped in a markdown code fence; reply with raw JSON only"
    try:
        obj = json.loads(text)
    except json.JSONDecodeError as e:
        return None, f"reply is not valid JSON ({e.msg} at char {e.pos}); reply with the JSON object only"
    if not isinstance(obj, dict):
        return None, "reply must be a JSON object"
    return obj, None


def _numbers_in(raw: str) -> set[float]:
    cleaned = re.sub(r"(?<=\d),(?=\d{3})", "", raw)  # 1,299 -> 1299
    return {float(x) for x in re.findall(r"\d+(?:\.\d+)?", cleaned)}


def validate(obj: dict, raw: str = "") -> list[str]:
    p: list[str] = []
    extra, missing = set(obj) - KEYS, KEYS - set(obj)
    if extra:
        p.append(f"unexpected keys: {sorted(extra)}")
    if missing:
        p.append(f"missing keys: {sorted(missing)}")
    review = obj.get("needs_review")
    if not (isinstance(review, list) and all(isinstance(x, str) for x in review)):
        p.append("needs_review must be an array of strings")
        review = []
    if review == ["not a single product"]:
        return p  # the declared "nothing usable" answer; shape is checked above
    name = obj.get("name")
    if not isinstance(name, str) or not 3 <= len(name.strip()) <= 80:
        p.append("name must be a string of 3-80 characters")
    price = obj.get("price")
    if price is None:
        if "price" not in review:
            p.append('price is null but "price" is not listed in needs_review')
    elif not isinstance(price, dict) or set(price) != {"amount", "currency"}:
        p.append('price must be null or {"amount": number, "currency": "AED"}')
    else:
        amt, cur = price["amount"], price["currency"]
        if isinstance(amt, bool) or not isinstance(amt, (int, float)) or amt <= 0:
            p.append("price.amount must be a number greater than 0 (not a string)")
        elif raw and float(amt) not in _numbers_in(raw):
            p.append(f"price {amt} does not appear in the input; do not invent prices")
        if not isinstance(cur, str) or not CURRENCY.match(cur):
            p.append("price.currency must be a 3-letter upper-case code such as AED")
    sizes = obj.get("sizes")
    if not (isinstance(sizes, list) and all(isinstance(s, str) and s.strip() for s in sizes)):
        p.append("sizes must be an array of non-empty strings ([] if none)")
    else:
        if len(set(sizes)) != len(sizes):
            p.append("sizes contains duplicates")
        for s in sizes:
            if raw and not re.search(rf"(?<![\w.]){re.escape(s)}(?![\w])", raw, re.I):
                p.append(f"size {s!r} does not appear in the input")
    feats = obj.get("features")
    if not (isinstance(feats, list) and 1 <= len(feats) <= 8 and all(isinstance(f, str) and 0 < len(f) <= 80 for f in feats)):
        p.append("features must be 1-8 strings of at most 80 characters")
    elif len({f.lower() for f in feats}) != len(feats):
        p.append("features contains duplicates")
    desc = obj.get("description")
    if not isinstance(desc, str):
        p.append("description must be a string")
    else:
        words = len(desc.split())
        if not 20 <= words <= 60:
            p.append(f"description has {words} words; it must have 20-60")
        if "!" in desc:
            p.append("description must not contain exclamation marks")
        bad = [h for h in HYPE if re.search(rf"\b{h}\b", desc, re.I)]
        if bad:
            p.append(f"description uses hype words: {bad}")
        if raw:
            new = _numbers_in(desc) - _numbers_in(raw)
            if new:
                p.append(f"description contains numbers not in the input: {sorted(new)}")
    return p
