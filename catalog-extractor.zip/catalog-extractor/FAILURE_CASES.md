# Failure cases

Each row says what goes wrong, what the code does about it, and whether a test covers it.
"Caught" means validation rejects the reply and the retry shows the model the exact problem.
"Known gap" means validation cannot catch it, so a person has to.

| # | Failure | Example | Handling | Test |
| --- | --- | --- | --- | --- |
| 1 | Reply wrapped in a markdown fence | ```` ```json {...} ``` ```` | Caught, rejected (not silently stripped), retried | `test_fenced_json_rejected` |
| 2 | Chatty reply, not JSON | `Sure! Here it is: {...}` | Caught, retried | `test_prose_rejected` |
| 3 | Price as a string | `"amount": "349"` | Caught | `test_price_as_string` |
| 4 | Invented price | input says 349, reply says 299 | Caught: the number must appear in the input | `test_invented_price`, `test_hallucinated_price_then_fixed` |
| 5 | Price missing from input | no price anywhere | Model must return `null` and list `price` in `needs_review`; `null` without that is rejected | `test_null_price_needs_review`, `test_null_price_declared_ok` |
| 6 | Currency not a 3-letter code | `Dhs` | Caught | `test_bad_currency` |
| 7 | Invented size | `47` not in the input | Caught (whole-token match) | `test_invented_size` |
| 8 | Duplicate sizes or features | `["40","40"]` | Caught | `test_duplicate_sizes` |
| 9 | Too few or too many features | `[]`, or 9 items | Caught | `test_no_features`, `test_too_many_features` |
| 10 | Description too short or long | `Nice shoe.` | Caught (20-60 words) | `test_short_description` |
| 11 | Hype words or `!` in description | `the best shoe!` | Caught | `test_hype_and_bang` |
| 12 | Invented number in description | `Tested for 500 hours` | Caught: numbers must come from the input | `test_invented_number_in_description` |
| 13 | Extra or missing keys | `sku` added | Caught | `test_extra_key` |
| 14 | Input is not one product | a meeting email | Model returns the `not a single product` answer; accepted so a person can see it, and `needs_review` carries the reason | `test_declared_not_a_product` |
| 15 | API error or timeout | HTTP 529 | Counts as an attempt; the backend also retries 429/5xx with backoff | `test_api_error_is_an_attempt` |
| 16 | Still invalid after all attempts | model keeps failing | `extract` returns `ok=False` with every reply and its problems; the CLI exits 1 | `test_gives_up_after_max` |
| 17 | **Known gap:** old price vs sale price | `Dhs 349 (was 420)`; reply says 420 | Not caught: both numbers are in the input. The prompt tells the model to use the current price; check price changes by eye | `test_old_price_is_grounded_but_allowed` |
| 18 | **Known gap:** negated size | `(no 46)`; reply lists 46 | Not caught: a text match cannot read "no" | `test_known_gap_negated_size` |
| 19 | **Known gap:** OCR typos | `5OO ml` (letter O) | The model may write `500 ml` in the description; check 12 then rejects it as an invented number. The retry usually drops the number. Fix the typo in the input if it keeps failing | none (needs live model) |
| 20 | **Known gap:** wrong but grounded facts | colour taken from the wrong row of a spreadsheet | Not caught: every word is in the input | none |
| 21 | **Known gap:** non-English input | Arabic notes | Name and features may come out in Arabic; the word-count and hype checks assume English | none |
| 22 | **Known gap:** two currencies in the input | `$40 / Dhs 150` | Model must pick one; no check that it picked the shop's currency | none |

## What the retry loop does not do

- It does not repair JSON for the model. A bad reply costs another call so the model learns what was wrong.
- It stops after 3 attempts by default (`--attempts`). A failed product goes to a person; it is never published half-valid.
- A valid reply can still list fields in `needs_review`. Treat those as "publish after a human fills them in".

## Not tested live

The unit tests use a scripted fake model. The real `AnthropicModel` has not been run here (no API key), and the prompt itself has not been scored on real model replies. Run the four files in `examples/` first and read the results.
