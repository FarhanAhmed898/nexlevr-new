import json
import unittest
from pathlib import Path

from catalog.extract import extract
from catalog.validate import parse_json, validate

EX = Path(__file__).parent.parent / "examples"
NOTE = (EX / "supplier_note.txt").read_text()
GOOD = {"name": "AirRun 2 running shoe", "price": {"amount": 349, "currency": "AED"},
        "sizes": ["40", "41", "42", "43", "44", "45"],
        "features": ["Mesh upper", "Foam sole", "Reflective heel tab"],
        "description": "A lightweight running shoe with a breathable mesh upper and a foam sole. "
                       "The reflective heel tab helps you stay visible, and it comes in black and white.",
        "needs_review": []}


def j(**kw):
    d = dict(GOOD); d.update(kw); return json.dumps(d)


class Scripted:
    def __init__(self, *replies): self.replies, self.prompts = list(replies), []
    def generate(self, prompt):
        self.prompts.append(prompt); return self.replies.pop(0)


class Failures(unittest.TestCase):
    def problems(self, **kw): return validate(json.loads(j(**kw)), NOTE)

    def test_good_passes(self): self.assertEqual(validate(GOOD, NOTE), [])
    def test_fenced_json_rejected(self): self.assertIn("fence", parse_json("```json\n{}\n```")[1])
    def test_prose_rejected(self): self.assertIn("not valid JSON", parse_json("Sure! Here it is: {}")[1])
    def test_price_as_string(self): self.assertTrue(self.problems(price={"amount": "349", "currency": "AED"}))
    def test_invented_price(self): self.assertTrue(any("do not invent" in x for x in self.problems(price={"amount": 299, "currency": "AED"})))
    def test_old_price_is_grounded_but_allowed(self):  # 420 is in the note; grounding cannot tell old from new (documented)
        self.assertEqual(self.problems(price={"amount": 420, "currency": "AED"}), [])
    def test_null_price_needs_review(self): self.assertTrue(self.problems(price=None))
    def test_null_price_declared_ok(self): self.assertEqual(self.problems(price=None, needs_review=["price"]), [])
    def test_bad_currency(self): self.assertTrue(self.problems(price={"amount": 349, "currency": "Dhs"}))
    def test_invented_size(self): self.assertTrue(self.problems(sizes=["40", "47"]))
    def test_known_gap_negated_size(self):  # note says "(no 46)"; a text check cannot read negation, so this passes. Documented.
        self.assertEqual(self.problems(sizes=["40", "46"]), [])
    def test_duplicate_sizes(self): self.assertTrue(self.problems(sizes=["40", "40"]))
    def test_no_features(self): self.assertTrue(self.problems(features=[]))
    def test_too_many_features(self): self.assertTrue(self.problems(features=[f"f{i}" for i in range(9)]))
    def test_short_description(self): self.assertTrue(self.problems(description="Nice shoe."))
    def test_hype_and_bang(self): self.assertEqual(len(self.problems(description="This is the best shoe ever made for running and walking and everything else you could want to do in a day! " * 1)), 2)
    def test_invented_number_in_description(self):
        d = GOOD["description"] + " Tested for 500 hours."
        self.assertTrue(any("numbers not in the input" in x for x in self.problems(description=d)))
    def test_extra_key(self): self.assertTrue(any("unexpected keys" in x for x in validate({**GOOD, "sku": "x"}, NOTE)))
    def test_declared_not_a_product(self):
        o = {"name": "", "price": None, "sizes": [], "features": [], "description": "", "needs_review": ["not a single product"]}
        self.assertEqual(validate(o, "meeting moved"), [])
    def test_examples_ground(self):
        flask = {**GOOD, "name": "Steel flask", "price": {"amount": 59.0, "currency": "AED"}, "sizes": [],
                 "description": "A vacuum insulated steel flask with a BPA free lid. It keeps drinks cold for 24 hours and hot for 12 hours, so it suits a long day out or a daily commute."}
        self.assertEqual(validate(flask, (EX / "ocr_photo.txt").read_text()), [])


class Retry(unittest.TestCase):
    def test_first_try(self):
        m = Scripted(j()); r = extract(NOTE, m)
        self.assertTrue(r.ok); self.assertEqual(r.attempts, 1)

    def test_retry_feeds_problems_back(self):
        m = Scripted("```json\n{}\n```", j()); r = extract(NOTE, m)
        self.assertTrue(r.ok); self.assertEqual(r.attempts, 2)
        self.assertIn("REJECTED", m.prompts[1]); self.assertIn("markdown code fence", m.prompts[1])
        self.assertNotIn("REJECTED", m.prompts[0])

    def test_gives_up_after_max(self):
        m = Scripted("nope", "nope", "nope"); r = extract(NOTE, m)
        self.assertFalse(r.ok); self.assertEqual(r.attempts, 3); self.assertEqual(len(r.history), 3)

    def test_api_error_is_an_attempt(self):
        class Boom:
            n = 0
            def generate(self, p):
                Boom.n += 1
                if Boom.n == 1: raise RuntimeError("API error 529")
                return j()
        r = extract(NOTE, Boom()); self.assertTrue(r.ok); self.assertEqual(r.attempts, 2)

    def test_hallucinated_price_then_fixed(self):
        m = Scripted(j(price={"amount": 299, "currency": "AED"}), j()); r = extract(NOTE, m)
        self.assertTrue(r.ok); self.assertIn("do not invent", m.prompts[1])


if __name__ == "__main__":
    unittest.main()
