# Catalogue extractor

Turns messy product information (supplier notes, OCR text from photos, spreadsheet rows) into strict JSON for a website catalogue:
`name`, `price`, `sizes`, `features`, `description` (plus `needs_review` for anything missing).

Standard library only.

```bash
export ANTHROPIC_API_KEY=...
python -m catalog examples/supplier_note.txt        # prints JSON, exit 0
python -m catalog examples/not_a_product.txt        # exit 1 or a "not a single product" answer
python -m unittest discover -s tests -t .           # 25 offline tests
```

How it works (`catalog/`):

- `prompt.py` is the prompt. Rules: JSON only, fixed keys, use only facts in the input, `null` plus `needs_review` instead of guessing.
- `validate.py` checks the reply against the schema and against the input (price, sizes and numbers must appear in the source text).
- `extract.py` runs prompt, parse, validate. On a rejection it re-sends the prompt with the list of problems and the previous reply, up to 3 attempts.

Output shape:

```json
{"name": "AirRun 2 running shoe", "price": {"amount": 349, "currency": "AED"},
 "sizes": ["40","41","42","43","44","45"],
 "features": ["Mesh upper", "Foam sole", "Reflective heel tab"],
 "description": "20-60 words, no hype, no invented numbers.", "needs_review": []}
```

See `FAILURE_CASES.md` for the 22 failure cases, which ones are caught and which are known gaps.
