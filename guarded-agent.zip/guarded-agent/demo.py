"""Short demo of each guardrail. Offline: a scripted mock plays the model.   python3 demo.py"""
import agent
from agent import run
from guardrails import Guardrails
from mock import Script

agent.OUTBOX.unlink(missing_ok=True)
def banner(t): print(f"\n=== {t} ===")

banner("1. STEP LIMIT: model loops forever on lookup_price, stopped at 3 steps")
g = Guardrails(max_steps=3)
print(run("price?", Script([("lookup_price", {"product_name": "flask"})]), g))

banner("2. ALLOWED TOOLS: model tries delete_file, which was never offered")
g = Guardrails()
print(run("clean up", Script([("delete_file", {"path": "/"}), "Could not delete."]), g))
print("log:", g.log)

banner("3. COST CAP: $0.003/step against a $0.005 cap")
g = Guardrails(max_cost_usd=0.005, price_in_per_m=1.0, price_out_per_m=5.0)
print(run("price?", Script([("lookup_price", {"product_name": "flask"})], tokens=(1000, 400)), g))

banner("4a. HUMAN APPROVAL: denied, nothing published")
g = Guardrails(allowed_tools=frozenset({"lookup_price", "publish_post"}), approve=lambda n, a: False)
print(run("post it", Script([("publish_post", {"text": "Sale today!"}), "Not posted."]), g))
print("outbox exists:", agent.OUTBOX.exists())

banner("4b. HUMAN APPROVAL: approved, simulated post written to outbox.jsonl")
g = Guardrails(allowed_tools=frozenset({"lookup_price", "publish_post"}), approve=lambda n, a: True)
print(run("post it", Script([("publish_post", {"text": "Sale today!"}), "Posted."]), g))
print("outbox:", agent.OUTBOX.read_text().strip())
agent.OUTBOX.unlink(missing_ok=True)
