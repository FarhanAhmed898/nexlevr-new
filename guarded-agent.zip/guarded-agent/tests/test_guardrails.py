import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
import agent
from agent import run
from guardrails import Guardrails
from mock import Script

LOOK = ("lookup_price", {"product_name": "flask"})
POST = ("publish_post", {"text": "hi"})


class T(unittest.TestCase):
    def setUp(self): agent.OUTBOX.unlink(missing_ok=True)
    tearDown = setUp

    def test_happy_path(self):
        out = run("p", Script([LOOK, "It costs 59."]), Guardrails())
        self.assertEqual(out, "It costs 59.")

    def test_step_limit(self):
        g = Guardrails(max_steps=3); s = Script([LOOK])
        self.assertIn("step limit", run("p", s, g)); self.assertEqual(s.i, 3)

    def test_unlisted_tool_not_shown_and_blocked(self):
        seen = []
        class Spy(Script):
            def create(self, m, tools): seen.append([t["name"] for t in tools]); return super().create(m, tools)
        g = Guardrails()
        run("x", Spy([("delete_file", {"path": "/"}), "ok"]), g)
        self.assertEqual(seen[0], ["lookup_price"])
        self.assertEqual(g.log[0]["event"], "blocked_not_allowed")

    def test_cost_cap_stops_before_next_call(self):
        g = Guardrails(max_cost_usd=0.005); s = Script([LOOK], tokens=(1000, 400))  # $0.003 per call
        self.assertIn("cost cap", run("p", s, g)); self.assertEqual(s.i, 2)
        self.assertLess(g.spent_usd, 0.01)

    def test_cost_math(self):
        g = Guardrails(); g.add_usage({"input_tokens": 1_000_000, "output_tokens": 1_000_000})
        self.assertAlmostEqual(g.spent_usd, 6.0)

    def test_approval_denied_means_no_side_effect(self):
        g = Guardrails(allowed_tools=frozenset({"lookup_price", "publish_post"}), approve=lambda n, a: False)
        run("p", Script([POST, "ok"]), g)
        self.assertFalse(agent.OUTBOX.exists()); self.assertEqual(g.log[0]["event"], "denied")

    def test_no_approver_defaults_to_deny(self):
        g = Guardrails(allowed_tools=frozenset({"lookup_price", "publish_post"}))
        run("p", Script([POST, "ok"]), g)
        self.assertFalse(agent.OUTBOX.exists())

    def test_approval_granted_runs_once(self):
        asked = []
        g = Guardrails(allowed_tools=frozenset({"lookup_price", "publish_post"}), approve=lambda n, a: asked.append((n, a)) or True)
        run("p", Script([POST, "done"]), g)
        self.assertEqual(len(asked), 1); self.assertEqual(len(agent.OUTBOX.read_text().splitlines()), 1)

    def test_approval_tool_not_allowed_never_asks_human(self):
        asked = []
        g = Guardrails(approve=lambda n, a: asked.append(n) or True)  # publish_post not on allow-list
        run("p", Script([POST, "ok"]), g)
        self.assertEqual(asked, []); self.assertFalse(agent.OUTBOX.exists())

    def test_lookup_needs_no_approval(self):
        asked = []
        run("p", Script([LOOK, "ok"]), Guardrails(approve=lambda n, a: asked.append(n) or True))
        self.assertEqual(asked, [])


if __name__ == "__main__":
    unittest.main()
