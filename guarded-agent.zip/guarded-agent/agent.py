"""Tool-using agent with guardrails. Real side effects are simulated: approved sends and posts
are appended to outbox.jsonl, nothing leaves the machine."""
import json
import sys
from pathlib import Path

from guardrails import Guardrails

HERE = Path(__file__).parent
OUTBOX = HERE / "outbox.jsonl"


def lookup_price(product_name):
    import csv
    for row in csv.DictReader(open(HERE / "prices.csv", encoding="utf-8")):
        if product_name.lower() in row["product"].lower():
            return {"found": True, "product": row["product"], "price_aed": float(row["price_aed"])}
    return {"found": False}


def send_email(to, subject, body):
    _out({"kind": "email", "to": to, "subject": subject, "body": body}); return {"sent": True}


def publish_post(text):
    _out({"kind": "post", "text": text}); return {"published": True}


def _out(rec):
    with open(OUTBOX, "a") as f:
        f.write(json.dumps(rec) + "\n")


FUNCS = {"lookup_price": lookup_price, "send_email": send_email, "publish_post": publish_post}
SCHEMAS = {
    "lookup_price": {"name": "lookup_price", "description": "Price in AED of a product.",
                     "input_schema": {"type": "object", "properties": {"product_name": {"type": "string"}}, "required": ["product_name"]}},
    "send_email": {"name": "send_email", "description": "Send an email (needs human approval).",
                   "input_schema": {"type": "object", "properties": {"to": {"type": "string"}, "subject": {"type": "string"}, "body": {"type": "string"}}, "required": ["to", "subject", "body"]}},
    "publish_post": {"name": "publish_post", "description": "Publish a social post (needs human approval).",
                     "input_schema": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}},
    "delete_file": {"name": "delete_file", "description": "Delete a file.",
                    "input_schema": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}},
}


def run(task, client, g: Guardrails):
    # Guardrail 2a: the model is only shown tools on the allowed list.
    tools = [SCHEMAS[n] for n in SCHEMAS if g.permitted(n)]
    messages = [{"role": "user", "content": task}]
    for step in range(1, g.max_steps + 1):            # Guardrail 1: step limit
        if g.over_budget():                           # Guardrail 3: cost cap, checked before every call
            g.note("stopped_cost", spent=round(g.spent_usd, 4))
            return f"STOPPED: cost cap ${g.max_cost_usd:.3f} reached (spent ${g.spent_usd:.4f})."
        reply = client.create(messages, tools)
        g.add_usage(reply.get("usage", {}))
        messages.append({"role": "assistant", "content": reply["content"]})
        if reply["stop_reason"] != "tool_use":
            return "".join(b.get("text", "") for b in reply["content"])
        results = []
        for b in (b for b in reply["content"] if b["type"] == "tool_use"):
            ok, why = g.check(b["name"], b["input"])  # Guardrails 2b and 4: enforced at execution
            if ok:
                try:
                    out, err = json.dumps(FUNCS[b["name"]](**b["input"])), False
                except Exception as e:
                    out, err = f"Error: {e}", True
            else:
                out, err = f"Blocked: {why}", True
            results.append({"type": "tool_result", "tool_use_id": b["id"], "content": out, **({"is_error": True} if err else {})})
        messages.append({"role": "user", "content": results})
    g.note("stopped_steps", steps=g.max_steps)
    return f"STOPPED: step limit ({g.max_steps}) reached."


def cli_approver(name, args):
    print(f"\nAPPROVAL NEEDED: {name} {json.dumps(args)}")
    return input("Type 'yes' to allow: ").strip().lower() == "yes"
