"""Four guardrails around a tool-using agent. Enforced in code, not by asking the model nicely.

1. Step limit      max_steps model calls per run
2. Allowed tools   only these tools are shown to the model AND only these can run
3. Cost cap        estimated spend (from token usage) may not pass max_cost_usd
4. Human approval  tools in `needs_approval` run only if a person says yes
"""
from dataclasses import dataclass, field
from typing import Callable, Optional


@dataclass
class Guardrails:
    max_steps: int = 6
    allowed_tools: frozenset = frozenset({"lookup_price"})
    needs_approval: frozenset = frozenset({"send_email", "publish_post"})
    max_cost_usd: float = 0.05
    # ASSUMED prices (USD per million tokens). Replace with your model's real prices.
    price_in_per_m: float = 1.0
    price_out_per_m: float = 5.0
    approve: Optional[Callable[[str, dict], bool]] = None  # None = deny everything
    spent_usd: float = 0.0
    log: list = field(default_factory=list)

    def note(self, event, **kw):
        self.log.append({"event": event, **kw})

    # 3. cost
    def add_usage(self, usage: dict):
        self.spent_usd += (usage.get("input_tokens", 0) * self.price_in_per_m
                           + usage.get("output_tokens", 0) * self.price_out_per_m) / 1e6

    def over_budget(self) -> bool:
        return self.spent_usd >= self.max_cost_usd

    # 2. allow-list (side-effect tools must also be allowed to be proposed at all)
    def permitted(self, name: str) -> bool:
        return name in self.allowed_tools

    # 4. approval
    def check(self, name: str, args: dict):
        """Return (ok, reason). Order: allow-list first, then human approval."""
        if not self.permitted(name):
            self.note("blocked_not_allowed", tool=name)
            return False, f"tool '{name}' is not on the allowed list"
        if name in self.needs_approval:
            ok = bool(self.approve and self.approve(name, args))
            self.note("approved" if ok else "denied", tool=name, args=args)
            if not ok:
                return False, "a human denied this action (or no approver was available)"
        return True, ""
