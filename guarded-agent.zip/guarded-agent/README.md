# Agent with four guardrails

A tool-using agent loop wrapped in four limits that are enforced **in code**, so the model cannot talk its way past them.

| # | Guardrail | Where | What happens when it trips |
|---|-----------|-------|----------------------------|
| 1 | Step limit (`max_steps`) | `run()` loop | run ends: `STOPPED: step limit` |
| 2 | Allowed tools (`allowed_tools`) | tool list shown to the model **and** checked again at execution | unlisted tool never offered; if requested anyway it returns `Blocked` |
| 3 | Cost cap (`max_cost_usd`) | checked before every model call, from token usage | run ends: `STOPPED: cost cap` |
| 4 | Human approval (`needs_approval`) | checked at execution, after the allow-list | denied (or no approver) = tool does not run |

Default policy: `lookup_price` is allowed and read-only. `send_email` and `publish_post` need approval and are off the allow-list until you add them. `delete_file` exists in the schema list but is never allowed.

## Run
```
python3 demo.py                                   # one short demo per guardrail, offline
python3 -m unittest discover -s tests -t .        # 10 tests
```
To use with a real model, pass any client with `create(messages, tools)` returning an Anthropic-style reply (`content`, `stop_reason`, `usage`), and use `cli_approver` for real yes/no prompts.

## Honest notes
- The demo and tests use a **scripted mock**, not a language model, and were **not run against the live API**.
- "Posts, sends, publishes" are **simulated**: an approved action appends to `outbox.jsonl`. Nothing leaves the machine. Wiring a real email or social API is a separate step and should keep the same approval check.
- Prices per million tokens in `guardrails.py` are **assumptions**. Replace them with your model's real prices. The cap is checked before each call, so one call can overshoot it by that call's cost.
- Order matters: a tool that is not allowed never reaches the human, so people are not asked to approve things that were never permitted.
