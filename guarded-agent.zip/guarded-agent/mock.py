"""Scripted stand-in for the model (NOT a language model). Replays a list of replies and reports fake token usage."""
class Script:
    def __init__(self, steps, tokens=(500, 200)):
        self.steps, self.i, self.tokens = steps, 0, tokens

    def create(self, messages, tools):
        s = self.steps[min(self.i, len(self.steps) - 1)]; self.i += 1
        usage = {"input_tokens": self.tokens[0], "output_tokens": self.tokens[1]}
        if isinstance(s, str):
            return {"stop_reason": "end_turn", "content": [{"type": "text", "text": s}], "usage": usage}
        name, args = s
        return {"stop_reason": "tool_use", "usage": usage,
                "content": [{"type": "tool_use", "id": f"t{self.i}", "name": name, "input": args}]}
