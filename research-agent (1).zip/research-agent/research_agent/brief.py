"""Ask the model for claims with quotes, verify them in code, render the brief."""
import datetime
import json
import re

SYSTEM = """You write a company brief using ONLY the numbered source pages given.
Return JSON only, in this shape:
{"sells":[C],"customers":[C],"online_presence":[C],
 "ideas":[{"idea":"...","why":"...","basis":"S1"}]}
where C = {"text":"one factual sentence","source":"S1","quote":"exact words copied from that page"}.
Rules: every claim needs a source id and a quote copied exactly from that page.
If the pages do not say it, leave it out. Do not guess. At most 3 claims per section
and exactly 3 ideas. Each idea's "basis" is the source id of the fact it builds on."""


def _norm(s):
    return re.sub(r"\s+", " ", re.sub(r"[‘’]", "'", re.sub(r"[“”]", '"', s))).strip().lower()


NEG = re.compile(r"\b(not|no|never|cannot|without|stopped|ceased|ended)\b|n't\b")


def _negated(page_norm, quote, claim_text):
    """True if every occurrence of the quote sits in a negated phrase and the claim itself is not negative."""
    if NEG.search(claim_text):
        return False
    spots = [m.start() for m in re.finditer(re.escape(quote), page_norm)]
    for i in spots:
        before = re.split(r"[.!?]", page_norm[max(0, i - 40):i])[-1]  # same sentence only
        if not NEG.search(before + " " + quote):
            return False
    return bool(spots)


def stale_year(claim, pages):
    """A year at least 3 years old near the quote, e.g. a 2014 staff count. Returns the year or None."""
    page = next((p for p in pages if p.id == claim.get("source")), None)
    if not page:
        return None
    n, q = _norm(page.text), _norm(str(claim.get("quote", "")))
    i = n.find(q)
    if i < 0:
        return None
    for y in re.findall(r"\b(19\d\d|20\d\d)\b", n[max(0, i - 80): i + len(q) + 80]):
        if int(y) <= datetime.date.today().year - 3:
            return y
    return None


def verify_claim(claim, pages):
    """Return (ok, reason). A claim passes only if its quote is on its page."""
    if not isinstance(claim, dict):
        return False, "malformed claim (not an object)"
    page = next((p for p in pages if p.id == claim.get("source")), None)
    if page is None:
        return False, "cites a source that was not fetched"
    quote = _norm(str(claim.get("quote", "")))
    if len(quote) < 15:
        return False, "no usable quote"
    if quote not in _norm(page.text):
        return False, "quote not found on the cited page"
    if _negated(_norm(page.text), quote, _norm(str(claim.get("text", "")))):
        return False, "the page says the opposite (the quote is negated there)"
    claim_nums = set(re.findall(r"\d[\d,.]*", str(claim.get("text", ""))))
    if not all(n in quote or n in _norm(page.text) for n in claim_nums):
        return False, "a number in the claim is not on the page"
    return True, ""


def ask_model(client, name, pages):
    ctx = "\n\n".join(f"[{p.id}] {p.url}\n{p.text}" for p in pages)
    user = f"Company: {name}\n\nSources:\n{ctx}"
    last = ""
    for attempt in range(2):  # one retry on bad JSON
        raw = client.complete(SYSTEM, user if attempt == 0 else user + "\n\nReturn valid JSON only.")
        data = extract_json(raw)
        if isinstance(data, dict):
            return data
        last = raw[:200]
    raise ValueError(f"model did not return valid JSON: {last!r}")


def extract_json(raw):
    """Find the first JSON object in the reply, even with chatter or stray braces around it."""
    dec = json.JSONDecoder()
    for m in re.finditer(r"\{", raw):
        try:
            obj, _ = dec.raw_decode(raw[m.start():])
        except ValueError:
            continue
        if isinstance(obj, dict) and any(k in obj for k in ("sells", "customers", "online_presence", "ideas")):
            return obj
    return None


MAX_PER_SECTION = 3


def build(name, pages, data):
    """Split everything the model said into verified and unverified. At most 3 claims per section."""
    ok, bad, ideas = {"sells": [], "customers": [], "online_presence": []}, [], []
    for sec in ok:
        items = data.get(sec) or []
        if not isinstance(items, list):
            bad.append((sec, str(items)[:60], "section was not a list"))
            continue
        for c in items:
            good, why = verify_claim(c, pages)
            if not good:
                bad.append((sec, (c.get("text", "?") if isinstance(c, dict) else str(c))[:90], why))
            elif len(ok[sec]) < MAX_PER_SECTION:
                y = stale_year(c, pages)
                ok[sec].append({**c, "text": c["text"] + (f" (source dated {y})" if y else "")})
            else:
                bad.append((sec, c["text"][:90], "left out: more than 3 claims in this section (one-page limit)"))
    for i in (data.get("ideas") or [])[:3]:
        if not isinstance(i, dict):
            ideas.append(({"idea": str(i)[:90], "why": "", "basis": None}, False, "malformed idea (not an object)"))
            continue
        good, why = verify_claim({"source": i.get("basis"), "quote": i.get("quote", ""), "text": ""}, pages) \
            if i.get("quote") else (any(p.id == i.get("basis") for p in pages), "basis source was not fetched")
        ideas.append((i, good, why))
    return ok, bad, ideas


def render(name, pages, ok, bad, ideas, notes):
    L = [f"# {name}: research brief", ""]
    titles = {"sells": "What they sell", "customers": "Who their customers are",
              "online_presence": "Online presence"}
    for sec, title in titles.items():
        L.append(f"## {title}")
        L += [f"- {c['text']} [{c['source']}]" for c in ok[sec]] or ["- Nothing verified from the sources found."]
        L.append("")
    L.append("## Three growth ideas (our suggestions, not facts)")
    for n, (i, good, _) in enumerate(ideas, 1):
        tag = f"[builds on {i.get('basis')}]" if good else "[basis not verified]"
        L.append(f"{n}. {i.get('idea', '?')}. {i.get('why', '')} {tag}")
    if not ideas:
        L.append("- No ideas could be tied to a fetched source.")
    L += ["", "## Could not verify"]
    flags = [f"- ({s}) {t}: {w}" for s, t, w in bad[:8]]
    if len(bad) > 8:
        flags.append(f"- ...and {len(bad) - 8} more flagged items")
    flags += [f"- (idea) {i.get('idea', '?')}: {w}" for i, g, w in ideas if not g]
    flags += [f"- Run note: {n}" for n in notes]
    L += flags or ["- Nothing flagged. Every claim's quote was found on its source page."]
    L += ["", "## Sources"] + [f"- [{p.id}] {p.url}" for p in pages]
    return "\n".join(L)
