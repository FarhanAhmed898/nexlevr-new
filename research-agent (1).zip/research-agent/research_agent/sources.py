"""Find and fetch public pages. Standard library only."""
import ipaddress
import re
import urllib.parse
import urllib.request
from dataclasses import dataclass
from html.parser import HTMLParser

UA = "Mozilla/5.0 (research-agent; student project)"


@dataclass
class Page:
    id: str
    url: str
    text: str


class _Text(HTMLParser):
    SKIP = {"script", "style", "noscript", "svg", "head"}

    def __init__(self):
        super().__init__()
        self.parts, self.depth = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.depth += 1

    def handle_endtag(self, tag):
        if tag in self.SKIP and self.depth:
            self.depth -= 1

    def handle_data(self, data):
        if not self.depth:
            self.parts.append(data)


def html_to_text(html: str) -> str:
    p = _Text()
    p.feed(html)
    return re.sub(r"\s+", " ", " ".join(p.parts)).strip()


def fetch(url: str, timeout: int = 15, max_bytes: int = 600_000) -> str:
    """Return page text, or raise on any failure."""
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read(max_bytes)
        charset = r.headers.get_content_charset() or "utf-8"
    return html_to_text(raw.decode(charset, errors="replace"))


def parse_ddg(html: str) -> list:
    urls = []
    for href in re.findall(r'class="result__a"[^>]*href="([^"]+)"', html):
        q = urllib.parse.urlparse(href).query
        target = urllib.parse.parse_qs(q).get("uddg", [href])[0]
        if target.startswith("http") and target not in urls:
            urls.append(target)
    return urls


def ddg_search(query: str, timeout: int = 15) -> list:
    url = "https://html.duckduckgo.com/html/?q=" + urllib.parse.quote(query)
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return parse_ddg(r.read().decode("utf-8", errors="replace"))


INJECTION = re.compile(
    r"ignore (all |any |the )?(previous|prior|above|earlier) (instructions|prompts?)|disregard (all |the )?(previous|above|prior)"
    r"|new instructions\s*:|you are now\b|system prompt|as an ai (language )?model|reveal your (instructions|prompt)", re.I)
STOP = {"inc", "ltd", "llc", "co", "corp", "the", "and", "company", "limited", "plc"}


def is_safe_url(u: str):
    """Only public http(s) pages. Blocks file:, ftp:, localhost and private or link-local IP addresses."""
    try:
        p = urllib.parse.urlparse(u)
    except ValueError:
        return False, "unreadable URL"
    if p.scheme not in ("http", "https"):
        return False, f"scheme '{p.scheme}' is not allowed"
    host = (p.hostname or "").lower()
    if not host or host == "localhost" or host.endswith((".local", ".internal", ".localhost")):
        return False, "local or internal host"
    try:
        ip = ipaddress.ip_address(host)
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
            return False, "private or reserved IP address"
    except ValueError:
        pass  # a normal domain name (DNS tricks are not covered: see README)
    return True, ""


def name_tokens(name):
    return [t for t in re.findall(r"[a-z0-9]{2,}", name.lower()) if t not in STOP]


def mentions(name, text):
    toks = name_tokens(name)
    low = text.lower()
    return all(t in low for t in toks)  # no usable tokens: cannot judge, so keep the page


def gather(name, seed_urls, search_fn=ddg_search, fetch_fn=fetch, max_pages=6):
    """Collect up to max_pages readable pages. Returns (pages, notes).

    notes lists every search or fetch that failed, so the brief can say
    what the agent could not reach."""
    notes, urls = [], []
    for u in seed_urls:
        if u not in urls:
            urls.append(u)
    for q in (name, f"{name} about", f"{name} customers reviews"):
        if len(urls) >= max_pages * 2:
            break
        try:
            for u in search_fn(q):
                if u not in urls:
                    urls.append(u)
        except Exception as e:  # network, blocking, parsing
            notes.append(f"search failed for '{q}': {e}")
    pages = []
    for u in urls:
        if len(pages) >= max_pages:
            break
        safe, why = is_safe_url(u)
        if not safe:
            notes.append(f"skipped {u}: {why}")
            continue
        try:
            text = fetch_fn(u)
        except Exception as e:
            notes.append(f"could not fetch {u}: {e}")
            continue
        if len(text) < 200:
            notes.append(f"{u}: too little text (likely needs JavaScript or a login)")
            continue
        if INJECTION.search(text):
            notes.append(f"{u}: quarantined, the page contains text that tries to instruct the AI")
            continue
        if not mentions(name, text):
            notes.append(f"{u}: dropped, the page never mentions '{name}'")
            continue
        pages.append(Page(f"S{len(pages) + 1}", u, text[:12000]))
    return pages, notes
