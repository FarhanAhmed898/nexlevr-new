import argparse
import sys

from .brief import ask_model, build, render
from .llm import AnthropicClient
from .sources import gather


def clean_name(name):
    n = " ".join(str(name).split())
    if not n:
        raise SystemExit("Give a business name.")
    if len(n) > 100 or len(n.split()) > 8 or "?" in n or any(ord(c) < 32 for c in str(name).replace("\n", " ")):
        raise SystemExit("That does not look like a business name (max 100 characters, 8 words, no questions).")
    return n


def run(name, client, seed_urls=(), search_fn=None, fetch_fn=None, max_pages=6):
    name = clean_name(name)
    kw = {k: v for k, v in (("search_fn", search_fn), ("fetch_fn", fetch_fn)) if v}
    pages, notes = gather(name, seed_urls, max_pages=max_pages, **kw)
    if not pages:
        raise SystemExit("No readable pages found, so no brief was written.\n" + "\n".join(notes))
    data = ask_model(client, name, pages)
    ok, bad, ideas = build(name, pages, data)
    return render(name, pages, ok, bad, ideas, notes)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="research_agent")
    ap.add_argument("business")
    ap.add_argument("--url", action="append", default=[], help="seed page (repeatable)")
    ap.add_argument("--out", help="write markdown here")
    a = ap.parse_args(argv)
    try:
        text = run(a.business, AnthropicClient(), a.url)
    except ValueError as e:
        raise SystemExit(f"The model's answer could not be used: {e}")
    if a.out:
        open(a.out, "w").write(text + "\n")
    print(text)


if __name__ == "__main__":
    sys.exit(main())
