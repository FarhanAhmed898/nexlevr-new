# Customer questions (DEMO DATA)
Q: Can I walk into the changing room with the studs out? A: Retract them first. The studs retract by 4 mm and the sole sits flat on tile.
Q: Will the boots work on artificial turf? A: The prototype is being tested on natural grass and artificial turf. Test results are not published yet.
Q: When can I buy a pair? A: Only the waitlist is open. The first prototype run is planned for 200 pairs.
