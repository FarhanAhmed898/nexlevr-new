# Market notes (DEMO DATA)
Amateur players often switch between outdoor pitches and indoor courts in one week.
Traditional boots have fixed studs that damage indoor floors, so many venues ask players to change shoes.
Social posts that show a short before-and-after of a feature tend to be easier to follow than long captions.
