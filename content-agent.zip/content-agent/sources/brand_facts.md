# Smart Cleats: brand facts (DEMO DATA, invented for this exercise)
Smart Cleats is a concept football boot with retractable spikes. The studs retract by 4 mm for walking on hard floors.
The boot is aimed at amateur players aged 16 to 30 who move between grass and indoor courts.
The design target weight is 290 grams per boot in a size 42.
The brand voice is friendly, direct and a little cheeky. It avoids medical or injury claims.
The first prototype run is planned for 200 pairs, and a waitlist is open on the website.
