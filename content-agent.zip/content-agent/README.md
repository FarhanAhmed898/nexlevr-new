# Multi-step content agent

Planner -> Researcher -> Writer -> Reviewer. It produces a weekly content pack for one brand (a blog draft, 3 social posts, a newsletter), logs every tool call, and the reviewer rejects claims that have no source.

```
python3 demo.py                                   # offline, scripted; writes out/demo/
python3 -m unittest discover -s tests -t .        # 14 tests
export ANTHROPIC_API_KEY=...
python3 run.py "Your brand" --sources sources --out out/week-1   # real model calls
```
Standard library only. Put your own brand notes as `.md` files in `sources/` (one fact per line).

## The four steps
| Step | Does | Guardrail |
|------|------|-----------|
| Planner | picks the angle, 3 to 4 research questions, one brief per deliverable | JSON only |
| Researcher | the model chooses tool calls; code runs them | only `search_notes` and `read_source` are allowed, both read-only and limited to `sources/`; anything else is blocked and logged |
| Writer | writes the pack from the notes only, with a note id like `[N2]` after each factual sentence | cannot see anything but the notes |
| Reviewer | **code, not a model**: checks every claim sentence | see below; one revision round, then anything still flagged is marked NEEDS A HUMAN CHECK in the files |

**Tool log:** every call (agent, tool, arguments, ok or failed, result size) is appended to `tool_calls.jsonl` and summarised in `review.md`. Blocked and failed calls are logged too.

**What the reviewer catches:** a sentence counts as a claim if it has a number, a `%`, or words like *only, first, best, proven, faster, lighter, injuries, studies*. A claim fails if it has (1) no `[N#]` citation, (2) a citation to a note that does not exist, (3) a number that is not in the cited note, or (4) a cited note that shares no wording with it.

## What was tested, honestly
- The 14 offline tests and the demo pass. The demo uses a **scripted client, not a language model**: I wrote draft 1 with four planted problems (an unsourced "clinically proven" claim, a made-up citation, a wrong number, a claim the source does not support) and the reviewer caught all four. Draft 2 is also scripted, so the demo shows the reviewer and the logging working, **not the quality of real writing**.
- **Never run against the live API** (no key in the build sandbox). Expect to tune prompts on the first real run.
- Brand facts in `sources/` are **invented demo data** for a fictional "Smart Cleats" concept. `examples/demo-pack/` is the demo output, not research.

## Limits
- The reviewer checks that a claim is sourced and matches the note's numbers and words. It cannot tell if a source is true, or catch a sentence that reuses a real note's words to say something else. A person should read the pack before it is posted.
- A short claim sentence with one shared word can pass. Opinion and tone are not checked.
- Nothing is posted or sent. Publishing would need the approval step from the guardrails project.
