import json, shutil, tempfile, unittest
from pathlib import Path
from content_agent.review import check_text, is_claim
from content_agent.tools import ToolBox, ToolLog
from content_agent.llm import ScriptedClient
from content_agent.pipeline import run

NOTES = {"N1": {"source": "a.md", "text": "The studs retract by 4 mm for walking on hard floors."},
         "N2": {"source": "a.md", "text": "The first prototype run is planned for 200 pairs."}}
SRC = Path(__file__).parent.parent / "sources"


class Review(unittest.TestCase):
    def reasons(self, t): return [i["reason"] for i in check_text("x", t, NOTES)]

    def test_unsourced_claim(self): self.assertEqual(self.reasons("Clinically proven to cut injuries by 40%."), ["claim with no source"])
    def test_good_claim_passes(self): self.assertEqual(self.reasons("The studs retract by 4 mm on hard floors [N1]."), [])
    def test_fabricated_id(self): self.assertIn("does not exist", self.reasons("Runs are 200 pairs [N9].")[0])
    def test_wrong_number(self): self.assertIn("number 300", self.reasons("The first prototype run is 300 pairs [N2].")[0])
    def test_source_does_not_say_it(self): self.assertIn("does not say", self.reasons("Our boots are lighter than any rival [N1].")[0])
    def test_plain_voice_not_flagged(self): self.assertEqual(self.reasons("Join the waitlist today. Friendly and cheeky."), [])
    def test_question_not_a_claim(self): self.assertFalse(is_claim("Why wait 5 minutes?"))
    def test_each_issue_names_its_sentence(self):
        i = check_text("post 2", "Best boot ever. Fine line.", NOTES)[0]
        self.assertEqual((i["where"], i["sentence"]), ("post 2", "Best boot ever."))


class Tools(unittest.TestCase):
    def test_blocked_and_logged(self):
        log = ToolLog(); box = ToolBox(SRC, log)
        out, err = box.call("r", "delete_source", {"name": "x"})
        self.assertIsNone(out); self.assertFalse(log.entries[0]["ok"]); self.assertIn("blocked", log.entries[0]["note"])

    def test_path_trick_stays_inside_folder(self):
        box = ToolBox(SRC, ToolLog()); out, err = box.call("r", "read_source", {"name": "../../etc/passwd"})
        self.assertIsNone(out); self.assertTrue(err)

    def test_every_call_logged_to_file(self):
        d = tempfile.mkdtemp(); log = ToolLog(Path(d) / "l.jsonl"); box = ToolBox(SRC, log)
        box.call("r", "search_notes", {"query": "studs retract"}); box.call("r", "read_source", {"name": "nope.md"})
        lines = (Path(d) / "l.jsonl").read_text().splitlines()
        self.assertEqual([json.loads(l)["ok"] for l in lines], [True, False])


class Pipeline(unittest.TestCase):
    def test_demo_end_to_end(self):
        import runpy, io, contextlib, os
        os.chdir(Path(__file__).parent.parent)
        with contextlib.redirect_stdout(io.StringIO()):
            g = runpy.run_path("demo.py")
        r = g["r"]
        self.assertEqual(len(r["first_issues"]), 4)
        self.assertEqual(r["final_issues"], [])
        self.assertEqual(sum(not e["ok"] for e in r["log"]), 1)   # the blocked delete_source
        self.assertEqual(len(r["log"]), 4)
        review = Path("out/demo/review.md").read_text()
        self.assertIn("claim with no source", review); self.assertNotIn("NEEDS A HUMAN", Path("out/demo/blog.md").read_text())
        shutil.rmtree("out", ignore_errors=True)

    def test_unfixed_claims_are_flagged_in_output(self):
        bad = {"blog": "Proven by studies [N1].", "posts": ["a", "b", "c"], "newsletter": "ok"}
        plan = {"angle": "x", "questions": [], "briefs": {}}
        c = ScriptedClient({"planner": [json.dumps(plan)], "researcher": [json.dumps({"calls": [{"tool": "search_notes", "args": {"query": "studs retract"}}]})],
                            "writer": [json.dumps(bad), json.dumps(bad)]})
        d = tempfile.mkdtemp(); r = run("B", "w", c, SRC, d)
        self.assertTrue(r["final_issues"]); self.assertIn("NEEDS A HUMAN CHECK", (Path(d) / "blog.md").read_text())

    def test_no_notes_no_pack(self):
        plan = {"angle": "x", "questions": [], "briefs": {}}
        c = ScriptedClient({"planner": [json.dumps(plan)], "researcher": [json.dumps({"calls": [{"tool": "search_notes", "args": {"query": "zzzz"}}]})], "writer": []})
        with self.assertRaises(SystemExit): run("B", "w", c, SRC, tempfile.mkdtemp())


if __name__ == "__main__":
    unittest.main()
