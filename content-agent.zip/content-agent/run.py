"""python3 __main__.py "Brand name" --sources sources --out out/week-1   (needs ANTHROPIC_API_KEY)"""
import argparse
import datetime
from content_agent.llm import AnthropicClient
from content_agent.pipeline import run

ap = argparse.ArgumentParser()
ap.add_argument("brand"); ap.add_argument("--sources", default="sources"); ap.add_argument("--out", default="out/latest")
a = ap.parse_args()
r = run(a.brand, datetime.date.today().isoformat(), AnthropicClient(), a.sources, a.out)
print(f"Wrote {a.out}. Caught in draft 1: {len(r['first_issues'])}. Still flagged: {len(r['final_issues'])}.")
