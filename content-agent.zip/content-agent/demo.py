"""Offline demo. A SCRIPTED client plays all four agents' model calls (it is not a language model).
Draft 1 contains four planted problems so you can watch the reviewer catch them.   python3 demo.py"""
import json
import shutil
from content_agent.llm import ScriptedClient
from content_agent.pipeline import run

PLAN = {"angle": "Walk off the pitch without changing shoes",
        "questions": ["How do the studs retract?", "When can people buy?", "Who is it for?"],
        "briefs": {"blog": "Explain the retractable studs", "social": "Three short posts", "newsletter": "Waitlist update"}}
CALLS = {"calls": [
    {"tool": "search_notes", "args": {"query": "retractable studs walking hard floors"}},
    {"tool": "search_notes", "args": {"query": "waitlist prototype run pairs"}},
    {"tool": "search_notes", "args": {"query": "players switch outdoor indoor courts weight grams"}},
    {"tool": "delete_source", "args": {"name": "brand_facts.md"}}]}   # not an allowed tool: must be blocked and logged

DRAFT1 = {
 "blog": "## Walk off the pitch without changing shoes\nSmart Cleats is a concept football boot with retractable spikes [N1]. The studs retract by 4 mm so the sole sits flat on tile [N3]. Our boots are clinically proven to cut injuries by 40%. Amateur players often switch between outdoor pitches and indoor courts in one week [N7].",
 "posts": ["Studs out on grass, studs in for the changing room. Retract them by 4 mm [N1].",
           "Our boots are lighter than any rival [N9].",
           "Join the waitlist. The first prototype run is planned for 200 pairs [N12]."],
 "newsletter": "Thanks for joining us. The first prototype run is 300 pairs [N4]. Only the waitlist is open for now [N5]."}

DRAFT2 = {
 "blog": "## Walk off the pitch without changing shoes\nSmart Cleats is a concept football boot with retractable spikes [N1]. The studs retract by 4 mm so the sole sits flat on tile [N3]. Amateur players often switch between outdoor pitches and indoor courts in one week [N7].",
 "posts": ["Studs out on grass, studs in for the changing room. Retract them by 4 mm [N1].",
           "Design target weight is 290 grams per boot in a size 42 [N9].",
           "Join the waitlist. The first prototype run is planned for 200 pairs [N4]."],
 "newsletter": "Thanks for joining us. The first prototype run is planned for 200 pairs [N4]. Only the waitlist is open for now [N5]."}

client = ScriptedClient({"planner": [json.dumps(PLAN)], "researcher": [json.dumps(CALLS)],
                         "writer": [json.dumps(DRAFT1), json.dumps(DRAFT2)]})
shutil.rmtree("out/demo", ignore_errors=True)
r = run("Smart Cleats (demo facts)", "2026-11-16", client, "sources", "out/demo")
print(f"Caught in draft 1: {len(r['first_issues'])}")
for i in r["first_issues"]:
    print(f"  ({i['where']}) {i['reason']}: {i['sentence'][:70]}")
print(f"Still flagged after revision: {len(r['final_issues'])}")
print(f"Tool calls logged: {len(r['log'])}  (see out/demo/tool_calls.jsonl)")
