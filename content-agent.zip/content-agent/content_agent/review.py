"""The reviewer is code, not a second opinion from the model: it checks every claim sentence
for a citation that exists and that actually supports the numbers and words in the sentence."""
import re

CITE = re.compile(r"\[(N\d+)\]")
CLAIM_WORDS = {"only", "first", "best", "proven", "guarantee", "guaranteed", "faster", "lighter", "reduces",
               "reduce", "prevents", "prevent", "clinically", "tested", "most", "always", "never", "leading",
               "award", "studies", "research", "percent", "safer", "cheaper", "injuries", "injury"}


def sentences(text):
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n+", text) if s.strip()]


def is_claim(s):
    if s.rstrip().endswith("?"):
        return False
    words = set(re.findall(r"[a-z]+", s.lower()))
    return bool(re.search(r"\d", CITE.sub("", s))) or "%" in s or bool(words & CLAIM_WORDS)


def _nums(s):
    return set(re.findall(r"\d+(?:\.\d+)?", CITE.sub("", s)))


def _words(s):
    """Word stems (first 6 letters of words with 5+ letters), so 'retract' matches 'retractable'."""
    return {w[:6] for w in re.findall(r"[a-z]{5,}", CITE.sub("", s).lower())}


def check_text(label, text, notes):
    """notes: {id: {"source","text"}}. Returns a list of issues."""
    issues = []
    for s in sentences(text):
        if not is_claim(s):
            continue
        ids = CITE.findall(s)
        if not ids:
            issues.append({"where": label, "sentence": s, "reason": "claim with no source"})
            continue
        missing = [i for i in ids if i not in notes]
        if missing:
            issues.append({"where": label, "sentence": s, "reason": f"cites {missing[0]}, which does not exist"})
            continue
        support = " ".join(notes[i]["text"] for i in ids)
        bad = [n for n in _nums(s) if n not in _nums(support)]
        if bad:
            issues.append({"where": label, "sentence": s, "reason": f"number {bad[0]} is not in the cited source"})
        elif len(_words(s) & _words(support)) < min(2, max(1, len(_words(s)))):
            issues.append({"where": label, "sentence": s, "reason": "cited source does not say this"})
    return issues


def review(pack, notes):
    issues = check_text("blog", pack["blog"], notes)
    for i, p in enumerate(pack["posts"], 1):
        issues += check_text(f"post {i}", p, notes)
    issues += check_text("newsletter", pack["newsletter"], notes)
    return issues
