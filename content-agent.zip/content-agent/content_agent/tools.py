"""Tools the researcher may use. Every call is logged, including blocked and failed ones."""
import json
import re
import time
from pathlib import Path


class ToolLog:
    def __init__(self, path=None):
        self.entries, self.path = [], path
        if path:
            Path(path).parent.mkdir(parents=True, exist_ok=True)
            Path(path).write_text("")

    def add(self, agent, tool, args, ok, result_chars, note=""):
        e = {"n": len(self.entries) + 1, "ts": round(time.time(), 3), "agent": agent, "tool": tool,
             "args": args, "ok": ok, "result_chars": result_chars, "note": note}
        self.entries.append(e)
        if self.path:
            with open(self.path, "a") as f:
                f.write(json.dumps(e) + "\n")


class ToolBox:
    """Allowed tools: search_notes(query), read_source(name). Both read only the sources folder."""
    ALLOWED = {"search_notes", "read_source"}

    def __init__(self, folder, log: ToolLog):
        self.folder, self.log = Path(folder), log

    def call(self, agent, tool, args):
        if tool not in self.ALLOWED:
            self.log.add(agent, tool, args, False, 0, "blocked: not an allowed tool")
            return None, f"tool '{tool}' is not allowed"
        try:
            out = getattr(self, tool)(**args)
            self.log.add(agent, tool, args, True, sum(len(x["text"]) for x in out))
            return out, ""
        except Exception as e:
            self.log.add(agent, tool, args, False, 0, str(e))
            return None, str(e)

    def read_source(self, name):
        p = (self.folder / Path(name).name)  # no path tricks: file name only
        lines = [l.strip() for l in p.read_text().splitlines() if l.strip() and not l.startswith("#")]
        return [{"source": p.name, "text": l} for l in lines]

    def search_notes(self, query):
        words = {w for w in re.findall(r"[a-z0-9]{4,}", query.lower())}
        hits = []
        for p in sorted(self.folder.glob("*.md")):
            for l in self.read_source(p.name):
                score = len(words & set(re.findall(r"[a-z0-9]{4,}", l["text"].lower())))
                if score:
                    hits.append((score, l))
        return [l for _, l in sorted(hits, key=lambda x: -x[0])[:4]]
