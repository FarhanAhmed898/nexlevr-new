from pathlib import Path

from . import agents
from .review import review
from .tools import ToolBox, ToolLog


def run(brand, week, client, sources, out_dir, max_revisions=1):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    log = ToolLog(out / "tool_calls.jsonl")
    box = ToolBox(sources, log)
    plan_ = agents.plan(client, brand, week)
    notes, tool_errors = agents.research(client, box, plan_)
    if not notes:
        raise SystemExit("Researcher found nothing in the sources, so nothing was written.")
    pack = agents.write(client, plan_, notes)
    first_issues = review(pack, notes)
    issues = first_issues
    for _ in range(max_revisions):
        if not issues:
            break
        pack = agents.write(client, plan_, notes, issues, pack)
        issues = review(pack, notes)
    _save(out, brand, week, plan_, notes, pack, first_issues, issues, tool_errors, log)
    return {"pack": pack, "notes": notes, "first_issues": first_issues, "final_issues": issues, "log": log.entries}


def _save(out, brand, week, plan_, notes, pack, first, final, tool_errors, log):
    src = "\n".join(f"- [{k}] {v['source']}: \"{v['text']}\"" for k, v in notes.items())
    banner = "" if not final else "> NEEDS A HUMAN CHECK: the reviewer still flags sentences. See review.md.\n\n"
    (out / "blog.md").write_text(f"{banner}{pack['blog']}\n\n## Sources\n{src}\n")
    (out / "social.md").write_text(banner + "\n\n".join(f"**Post {i}**\n{p}" for i, p in enumerate(pack["posts"], 1)) + f"\n\n## Sources\n{src}\n")
    (out / "newsletter.md").write_text(f"{banner}{pack['newsletter']}\n\n## Sources\n{src}\n")
    def fmt(items): return "\n".join(f"- ({i['where']}) \"{i['sentence']}\": {i['reason']}" for i in items) or "- none"
    (out / "review.md").write_text(
        f"# Review: {brand}, week of {week}\n\nAngle: {plan_['angle']}\n\n"
        f"## Caught in draft 1 ({len(first)})\n{fmt(first)}\n\n## Still flagged after revision ({len(final)})\n{fmt(final)}\n\n"
        f"## Tool calls: {len(log.entries)} logged (see tool_calls.jsonl)\n"
        + "".join(f"{e['n']}. {e['agent']} -> {e['tool']}({e['args']}) {'ok' if e['ok'] else 'FAILED: ' + e['note']}\n" for e in log.entries)
        + ("\nTool errors: " + "; ".join(tool_errors) + "\n" if tool_errors else ""))
