import json
import os
import urllib.request


class AnthropicClient:
    def __init__(self, model=None):
        self.key = os.environ.get("ANTHROPIC_API_KEY")
        if not self.key:
            raise SystemExit("Set ANTHROPIC_API_KEY, or run demo.py (scripted, offline).")
        self.model = model or os.environ.get("CONTENT_MODEL", "claude-sonnet-5-5")

    def complete(self, role, system, user):
        body = json.dumps({"model": self.model, "max_tokens": 3000, "system": system,
                           "messages": [{"role": "user", "content": user}]}).encode()
        req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=body, headers={
            "x-api-key": self.key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
        with urllib.request.urlopen(req, timeout=180) as r:
            return "".join(b.get("text", "") for b in json.load(r)["content"] if b["type"] == "text")


class ScriptedClient:
    """Replays prepared replies by role. NOT a language model: used for the offline demo and tests."""
    def __init__(self, replies):
        self.replies = {k: list(v) for k, v in replies.items()}
        self.calls = []

    def complete(self, role, system, user):
        self.calls.append(role)
        return self.replies[role].pop(0)
