import json
import re

PLANNER = ("You plan one week of content for a brand. Return JSON only: "
           '{"angle":"...","questions":["3 to 4 factual questions to research"],'
           '"briefs":{"blog":"...","social":"...","newsletter":"..."}}')
RESEARCHER = ('You research with tools. Available: search_notes{"query"}, read_source{"name"}. '
              'Return JSON only: {"calls":[{"tool":"search_notes","args":{"query":"..."}}]}. At most 6 calls.')
WRITER = ("Write the weekly content pack from the research notes ONLY. After every factual sentence, add the note id "
          "like [N2]. If the notes do not support a claim, leave it out. No medical or injury claims. "
          'Return JSON only: {"blog":"~200 words markdown","posts":["p1","p2","p3"],"newsletter":"~120 words"}.')


def _json(raw):
    m = re.search(r"\{.*\}", raw, re.S)
    if not m:
        raise ValueError(f"no JSON in model reply: {raw[:120]!r}")
    return json.loads(m.group(0))


def plan(client, brand, week):
    return _json(client.complete("planner", PLANNER, f"Brand: {brand}\nWeek of: {week}"))


def research(client, toolbox, plan_):
    """The model chooses calls; code runs them through the allowed ToolBox; notes keep exact source text."""
    calls = _json(client.complete("researcher", RESEARCHER, json.dumps(plan_["questions"])))["calls"][:6]
    notes, errors = {}, []
    for c in calls:
        out, err = toolbox.call("researcher", c.get("tool", ""), c.get("args", {}))
        if err:
            errors.append(f"{c.get('tool')}: {err}")
            continue
        for item in out:
            if not any(n["text"] == item["text"] for n in notes.values()):
                notes[f"N{len(notes) + 1}"] = item
    return notes, errors


def write(client, plan_, notes, issues=None, previous=None):
    ctx = "\n".join(f"[{k}] ({v['source']}) {v['text']}" for k, v in notes.items())
    user = f"Plan: {json.dumps(plan_['briefs'])}\n\nNotes:\n{ctx}"
    if issues:
        user += ("\n\nYour previous draft:\n" + json.dumps(previous) + "\n\nThe reviewer rejected these sentences. "
                 "Fix or remove each one:\n" + "\n".join(f"- ({i['where']}) {i['sentence']} -> {i['reason']}" for i in issues))
    return _json(client.complete("writer", WRITER, user))
