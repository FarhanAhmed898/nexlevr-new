**Post 1**
Studs out on grass, studs in for the changing room. Retract them by 4 mm [N1].

**Post 2**
Design target weight is 290 grams per boot in a size 42 [N9].

**Post 3**
Join the waitlist. The first prototype run is planned for 200 pairs [N4].

## Sources
- [N1] brand_facts.md: "Smart Cleats is a concept football boot with retractable spikes. The studs retract by 4 mm for walking on hard floors."
- [N2] market_notes.md: "Traditional boots have fixed studs that damage indoor floors, so many venues ask players to change shoes."
- [N3] customer_faq.md: "Q: Can I walk into the changing room with the studs out? A: Retract them first. The studs retract by 4 mm and the sole sits flat on tile."
- [N4] brand_facts.md: "The first prototype run is planned for 200 pairs, and a waitlist is open on the website."
- [N5] customer_faq.md: "Q: When can I buy a pair? A: Only the waitlist is open. The first prototype run is planned for 200 pairs."
- [N6] customer_faq.md: "Q: Will the boots work on artificial turf? A: The prototype is being tested on natural grass and artificial turf. Test results are not published yet."
- [N7] market_notes.md: "Amateur players often switch between outdoor pitches and indoor courts in one week."
- [N8] brand_facts.md: "The boot is aimed at amateur players aged 16 to 30 who move between grass and indoor courts."
- [N9] brand_facts.md: "The design target weight is 290 grams per boot in a size 42."
