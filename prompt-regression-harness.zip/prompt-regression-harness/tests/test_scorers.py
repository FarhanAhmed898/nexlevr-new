import unittest

from harness.scorers import score_exact_label, score_product_description

CASE = {
    "id": 1,
    "vars": {"product_name": "Travel Tumbler 350 ml", "details": "350 ml; keeps drinks hot for 6 hours; leak-proof lid; AED 98"},
    "must_include": ["350 ml", "6 hours", "leak-proof", "AED 98"],
}
GOOD = ("Keep your coffee hot from the first sip to the last. This travel tumbler holds 350 ml and keeps drinks "
        "hot for 6 hours, so a morning drink is still warm at lunch. The leak-proof lid lets you drop it straight "
        "into your bag without a worry, which suits a busy commute, a long meeting or a walk in the park. "
        "It costs AED 98. Order yours today.")


class ProductDescriptionScorer(unittest.TestCase):
    def test_good_output_passes_every_rule(self):
        result = score_product_description(CASE, GOOD)
        self.assertTrue(result.passed, result.failures)
        self.assertEqual(result.score, 1.0)

    def test_hype_word_and_exclamation_fail_r2(self):
        result = score_product_description(CASE, GOOD.replace("Order yours today.", "Order now!"))
        self.assertFalse(result.checks["R2_no_hype"])  # the exclamation mark alone fails it

    def test_invented_number_fails_r4(self):
        result = score_product_description(CASE, GOOD.replace("a busy commute", "a busy 12-minute commute"))
        self.assertFalse(result.checks["R4_no_new_numbers"])
        self.assertIn("12", result.failures[0])

    def test_missing_fact_fails_r3(self):
        result = score_product_description(CASE, GOOD.replace("leak-proof", "sealed"))
        self.assertFalse(result.checks["R3_all_facts"])

    def test_too_short_fails_r1(self):
        result = score_product_description(CASE, "Keep coffee hot for 6 hours. 350 ml, leak-proof, AED 98. Order yours today.")
        self.assertFalse(result.checks["R1_length"])

    def test_opening_with_product_name_fails_r5(self):
        result = score_product_description(CASE, "Travel Tumbler 350 ml " + GOOD)
        self.assertFalse(result.checks["R5_benefit_opening"])

    def test_long_call_to_action_fails_r6(self):
        result = score_product_description(CASE, GOOD.replace("Order yours today.", "Order yours today and make every single morning better."))
        self.assertFalse(result.checks["R6_call_to_action"])


class ExactLabelScorer(unittest.TestCase):
    def test_bare_label(self):
        self.assertTrue(score_exact_label({"expected": "negative"}, "negative").passed)

    def test_reasoning_then_arrow_label_uses_last_label(self):
        out = "Praise for the coffee but a wish for a mug; it has a request. => feature request"
        self.assertTrue(score_exact_label({"expected": "feature request"}, out).passed)

    def test_wrong_label_fails(self):
        self.assertFalse(score_exact_label({"expected": "positive"}, "negative").passed)

    def test_no_label_fails(self):
        self.assertFalse(score_exact_label({"expected": "positive"}, "I am not sure.").passed)


if __name__ == "__main__":
    unittest.main()
