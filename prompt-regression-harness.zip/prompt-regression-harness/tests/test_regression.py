import json
import shutil
import tempfile
import unittest
from pathlib import Path

from harness.cli import main
from harness.regress import compare

ROOT = Path(__file__).resolve().parent.parent


def fake_run(pass_flags, version="v1", sha="a", by_check=None):
    cases = [{"id": i, "passed": ok, "score": 1.0 if ok else 0.0, "checks": {}, "failures": [], "error": False}
             for i, ok in enumerate(pass_flags)]
    rate = sum(pass_flags) / len(pass_flags)
    return {"version": version, "template_sha": sha, "model": "mock:strict", "cases": cases,
            "summary": {"n": len(cases), "pass_rate": rate, "mean_score": rate, "errors": 0, "by_check": by_check or {}}}


class CompareTests(unittest.TestCase):
    def test_drop_beyond_tolerance_is_flagged(self):
        v = compare(fake_run([True] * 10), fake_run([True] * 8 + [False] * 2, "v2", "b"), tolerance=0.05)
        self.assertTrue(v["flags"])
        self.assertEqual(v["newly_failing"], [8, 9])
        self.assertTrue(v["prompt_changed"])

    def test_small_drop_within_tolerance_is_not_flagged(self):
        v = compare(fake_run([True] * 20), fake_run([True] * 19 + [False], "v2", "b"), tolerance=0.05)
        self.assertEqual(v["flags"], [])

    def test_strict_cases_flags_a_single_flip(self):
        v = compare(fake_run([True] * 20), fake_run([True] * 19 + [False], "v2", "b"), tolerance=0.05, strict_cases=True)
        self.assertTrue(v["flags"])

    def test_one_check_collapsing_is_flagged_even_if_overall_is_flat(self):
        base = fake_run([True] * 10, by_check={"R2": 1.0, "R6": 0.5})
        cand = fake_run([True] * 10, "v2", "b", by_check={"R2": 0.5, "R6": 1.0})
        self.assertTrue(any("R2" in f for f in compare(base, cand)["flags"]))

    def test_improvement_is_not_flagged(self):
        v = compare(fake_run([True] * 5 + [False] * 5), fake_run([True] * 9 + [False], "v2", "b"))
        self.assertEqual(v["flags"], [])
        self.assertEqual(len(v["newly_passing"]), 4)


class EndToEnd(unittest.TestCase):
    """Whole pipeline on the offline mock models: baseline, unchanged check, a bad edit, a good edit."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        shutil.copytree(ROOT / "library", self.tmp / "library")
        self.args = ["--library", str(self.tmp / "library"), "--runs", str(self.tmp / "runs"),
                     "--baselines", str(self.tmp / "baselines"), "--models", "mock:strict,mock:loose"]
        self.assertEqual(main(self.args + ["baseline", "product_description"]), 0)
        saved = json.loads((self.tmp / "baselines" / "product_description.json").read_text())["models"]
        self.assertEqual(saved["mock:strict"]["summary"]["pass_rate"], 1.0)  # the strict stand-in obeys the v3 prompt

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def _set_current(self, version, template=None):
        path = self.tmp / "library" / "product_description" / "prompt.json"
        spec = json.loads(path.read_text())
        if template:
            spec["versions"][version] = template
        spec["current"] = version
        path.write_text(json.dumps(spec))

    def test_unchanged_prompt_passes(self):
        self.assertEqual(main(self.args + ["check", "product_description"]), 0)

    def test_weakening_the_prompt_is_flagged(self):
        spec = json.loads((self.tmp / "library" / "product_description" / "prompt.json").read_text())
        weaker = spec["versions"]["v3"].replace("Do not use these words:", "Prefer to avoid:")
        self._set_current("v4", weaker)
        report = self.tmp / "report.md"
        code = main(self.args + ["check", "product_description", "--report", str(report)])
        self.assertEqual(code, 1)
        self.assertIn("REGRESSION", report.read_text())

    def test_reverting_to_the_older_v2_is_flagged(self):
        self._set_current("v2")
        self.assertEqual(main(self.args + ["check", "product_description"]), 1)

    def test_missing_baseline_is_reported(self):
        self.assertEqual(main(self.args + ["check", "review_sorting", "--require-baseline"]), 2)


if __name__ == "__main__":
    unittest.main()
