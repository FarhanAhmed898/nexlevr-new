"""Checks the real-API backend against a throwaway local server that mimics the Messages API."""
import json
import os
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from unittest import mock

from harness.models import AnthropicModel, get_model


class Handler(BaseHTTPRequestHandler):
    seen = []
    fail_first = False

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        Handler.seen.append({"path": self.path, "key": self.headers.get("x-api-key"),
                             "version": self.headers.get("anthropic-version"), "body": body})
        if Handler.fail_first and len(Handler.seen) == 1:
            self.send_response(529)
            self.end_headers()
            self.wfile.write(b'{"error":"overloaded"}')
            return
        payload = json.dumps({"content": [{"type": "text", "text": "negative"}]}).encode()
        self.send_response(200)
        self.send_header("content-type", "application/json")
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, *args):
        pass


class AnthropicBackend(unittest.TestCase):
    def setUp(self):
        Handler.seen, Handler.fail_first = [], False
        self.server = HTTPServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self.env = mock.patch.dict(os.environ, {
            "ANTHROPIC_API_KEY": "test-key",
            "ANTHROPIC_BASE_URL": f"http://127.0.0.1:{self.server.server_port}",
        })
        self.env.start()

    def tearDown(self):
        self.env.stop()
        self.server.shutdown()

    def test_request_shape_and_response_parsing(self):
        model = get_model("anthropic:claude-haiku-5-5")
        self.assertEqual(model.generate("hello"), "negative")
        sent = Handler.seen[0]
        self.assertEqual(sent["path"], "/v1/messages")
        self.assertEqual(sent["key"], "test-key")
        self.assertEqual(sent["version"], "2023-06-01")
        self.assertEqual(sent["body"]["model"], "claude-haiku-5-5")
        self.assertEqual(sent["body"]["messages"], [{"role": "user", "content": "hello"}])
        self.assertEqual(sent["body"]["temperature"], 0.0)

    def test_retries_after_an_overloaded_response(self):
        Handler.fail_first = True
        with mock.patch("harness.models.time.sleep"):
            self.assertEqual(AnthropicModel("claude-sonnet-5-5").generate("hi"), "negative")
        self.assertEqual(len(Handler.seen), 2)

    def test_missing_key_is_a_clear_error(self):
        with mock.patch.dict(os.environ, {"ANTHROPIC_API_KEY": ""}):
            with self.assertRaises(RuntimeError):
                AnthropicModel("claude-haiku-5-5").generate("hi")


if __name__ == "__main__":
    unittest.main()
