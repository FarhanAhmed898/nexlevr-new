# Prompt regression harness

Run a prompt library against test cases on two AI models, score every output with pass/fail rules, and **fail the build when a prompt change makes quality drop**.

Pure Python standard library: no installs, no dependencies.

## How it works

```
library/<prompt>/prompt.json   versions of the prompt text, which one is "current", which scorer to use
library/<prompt>/cases.json    test cases (variables for the prompt + what a good answer must contain)
baselines/<prompt>.json        the scores you accepted for the current version, per model
```

1. `baseline` runs the current version on every model and stores the scores.
2. You edit a prompt (add a version, change `current`).
3. `check` re-runs it, compares with the baseline, and exits with code 1 if quality dropped.

A drop is flagged when, for any model:

- the share of cases that fully pass fell by more than the tolerance (default 5 points),
- the mean score fell by more than the tolerance,
- any single rule (for example "no hype words") fell by more than the tolerance,
- the model calls started to error, or
- with `--strict-cases`, any case that used to pass now fails.

Improvements are never flagged, and the report lists which cases newly passed.

## Quick start

```bash
export ANTHROPIC_API_KEY=...                       # for the real models
python -m harness baseline                          # score every prompt on both models, store baselines
# ...edit library/product_description/prompt.json: add "v4", set "current": "v4"...
python -m harness check --report report.md          # exit 0 = fine, 1 = regression
python -m harness run product_description --version v1   # score one version, nothing stored as a baseline
```

Default models are `anthropic:claude-haiku-5-5` and `anthropic:claude-sonnet-5-5`. Change them with
`--models a,b` or `HARNESS_MODELS`. Temperature is 0 unless `HARNESS_TEMPERATURE` says otherwise (`none` omits it).

### Try it with no API key

Two offline stand-in models read which rules a prompt states and obey them (or not). They exist to test the harness, not to measure real models.

```bash
python -m harness --models mock:strict,mock:loose baseline product_description
# weaken the banned-words rule in a new version, then:
python -m harness --models mock:strict,mock:loose check product_description
```

```
| Model       | Baseline | Candidate | Pass rate    | Prompt changed | Verdict    |
| mock:strict | v3       | v4        | 100% -> 0%   | yes            | REGRESSION |
**mock:strict**: pass rate fell 100% -> 0%; ...; check R2_no_hype fell 100% -> 0%
exit code: 1
```

## What is in the library

| Prompt | Scorer | Cases |
| --- | --- | --- |
| `product_description` (v1 to v3) | six rules: length, no hype words, all facts present, no invented numbers, benefit-led opening, short call to action | 15 |
| `review_sorting` (v1 zero-shot, v2 step-by-step) | exact label: positive, negative or feature request | 30 |

## Add your own

- **A prompt:** make `library/<name>/prompt.json` (`{"scorer": "...", "current": "v1", "versions": {"v1": "text with {{variables}}"}}`) and `cases.json` (`[{"id": 1, "vars": {...}, ...}]`).
- **A scorer:** write `def score_x(case, output) -> CaseScore` in `harness/scorers.py` and register it in `SCORERS`.
- **A model:** add a class with `name` and `generate(prompt) -> str`, and a line in `get_model`.

## CI

`.github/workflows/ci.yml` runs the unit tests on every push. On pull requests that touch `library/`, it also runs `python -m harness check --require-baseline` when the repository has an `ANTHROPIC_API_KEY` secret, and writes the report to the job summary. Commit your `baselines/` folder so the pull request has something to compare with.

## Limits

- **Not run against the live API here.** The Anthropic backend is tested against a local fake server (request shape, response parsing, retries), but it has not been run with a real key. Try `python -m harness run review_sorting` first.
- Model output varies between runs, so a small tolerance is built in. With 15 cases, one case is 6.7 points, so use `--strict-cases` if you want to see every flip.
- The rules catch what they check (invented numbers, banned words, missing facts), not every invented claim. Read a sample of outputs.
- The cases here are small and written by hand. Add real examples from your own use.

## Tests

```bash
python -m unittest discover -s tests -v
```
