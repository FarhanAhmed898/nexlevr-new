"""Compare a candidate run with a stored baseline run and flag quality drops."""
from __future__ import annotations

import json
from pathlib import Path


def compare(baseline: dict, candidate: dict, tolerance: float = 0.05, strict_cases: bool = False) -> dict:
    """Return a verdict dict. 'flags' is empty when nothing regressed.

    A flag is raised when:
      - pass_rate fell by more than `tolerance` (e.g. 0.05 = 5 points),
      - mean_score fell by more than `tolerance`,
      - any single check (rule) fell by more than `tolerance`,
      - the candidate had model-call errors the baseline did not,
      - strict_cases is on and any case that passed in the baseline now fails.
    """
    b, c = baseline["summary"], candidate["summary"]
    tolerance += 1e-9  # a drop of exactly the tolerance is allowed; this absorbs float rounding
    flags = []
    drop = b["pass_rate"] - c["pass_rate"]
    if drop > tolerance:
        flags.append(f"pass rate fell {b['pass_rate']:.0%} -> {c['pass_rate']:.0%}")
    score_drop = b["mean_score"] - c["mean_score"]
    if score_drop > tolerance:
        flags.append(f"mean score fell {b['mean_score']:.2f} -> {c['mean_score']:.2f}")
    for name, before in b["by_check"].items():
        after = c["by_check"].get(name, 0.0)
        if before - after > tolerance:
            flags.append(f"check {name} fell {before:.0%} -> {after:.0%}")
    if c["errors"] > b["errors"]:
        flags.append(f"{c['errors']} model call errors (baseline {b['errors']})")

    before_pass = {x["id"]: x["passed"] for x in baseline["cases"]}
    newly_failing = [x["id"] for x in candidate["cases"] if before_pass.get(x["id"]) and not x["passed"]]
    newly_passing = [x["id"] for x in candidate["cases"] if before_pass.get(x["id"]) is False and x["passed"]]
    if strict_cases and newly_failing:
        flags.append("cases that passed before now fail: " + ", ".join(map(str, newly_failing)))

    return {
        "model": candidate["model"],
        "baseline_version": baseline["version"],
        "candidate_version": candidate["version"],
        "prompt_changed": baseline["template_sha"] != candidate["template_sha"],
        "baseline_pass_rate": b["pass_rate"],
        "candidate_pass_rate": c["pass_rate"],
        "newly_failing": newly_failing,
        "newly_passing": newly_passing,
        "flags": flags,
    }


def save_baseline(path: Path, prompt_name: str, runs: dict) -> None:
    """runs: model name -> run dict. Written as one JSON file per prompt."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"prompt": prompt_name, "models": runs}, indent=1))


def load_baseline(path: Path) -> dict | None:
    return json.loads(path.read_text())["models"] if path.is_file() else None


def render_report(prompt_name: str, verdicts: list) -> str:
    lines = [f"## {prompt_name}", "",
             "| Model | Baseline | Candidate | Pass rate | Prompt changed | Verdict |",
             "| --- | --- | --- | --- | --- | --- |"]
    for v in verdicts:
        verdict = "REGRESSION" if v["flags"] else "ok"
        lines.append(
            f"| {v['model']} | {v['baseline_version']} | {v['candidate_version']} | "
            f"{v['baseline_pass_rate']:.0%} -> {v['candidate_pass_rate']:.0%} | "
            f"{'yes' if v['prompt_changed'] else 'no'} | {verdict} |")
    for v in verdicts:
        if v["flags"]:
            lines += ["", f"**{v['model']}**: " + "; ".join(v["flags"])]
        if v["newly_failing"]:
            lines += [f"- cases that passed before and now fail: {', '.join(map(str, v['newly_failing']))}"]
    return "\n".join(lines) + "\n"
