"""Run one prompt version on one model over all its test cases and score the outputs."""
from __future__ import annotations

import datetime
from concurrent.futures import ThreadPoolExecutor

from .scorers import SCORERS


def run_version(prompt, version: str, model, workers: int = 4) -> dict:
    scorer = SCORERS[prompt.scorer]

    def one(case: dict) -> dict:
        try:
            output = model.generate(prompt.render(version, case))
        except Exception as err:  # a failed call counts as a failed case, never as a silent skip
            return {"id": case["id"], "output": "", "passed": False, "score": 0.0,
                    "checks": {}, "failures": [f"model call failed: {err}"], "error": True}
        result = scorer(case, output)
        return {"id": case["id"], "output": output, "passed": result.passed, "score": result.score,
                "checks": result.checks, "failures": result.failures, "error": False}

    with ThreadPoolExecutor(max_workers=workers) as pool:
        cases = list(pool.map(one, prompt.cases))

    n = len(cases)
    check_totals: dict = {}
    for c in cases:
        for name, ok in c["checks"].items():
            passed, total = check_totals.get(name, (0, 0))
            check_totals[name] = (passed + int(ok), total + 1)
    return {
        "prompt": prompt.name,
        "version": version,
        "template_sha": prompt.sha(version),
        "model": model.name,
        "ran_at": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
        "summary": {
            "n": n,
            "pass_rate": sum(c["passed"] for c in cases) / n if n else 0.0,
            "mean_score": sum(c["score"] for c in cases) / n if n else 0.0,
            "errors": sum(c["error"] for c in cases),
            "by_check": {k: v[0] / v[1] for k, v in check_totals.items()},
        },
        "cases": cases,
    }
