"""Prompt regression harness: run a prompt library on several models, score it, flag drops."""
