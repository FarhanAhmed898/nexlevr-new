"""Scorers: turn (test case, model output) into a pass/fail and a 0-1 score.

Every scorer is a plain function so you can add your own and register it in SCORERS.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

BANNED_WORDS = [
    "amazing", "perfect", "best", "ultimate", "incredible", "unbeatable",
    "game-changing", "revolutionary", "must-have", "stunning", "finest", "world-class",
]
CTA_VERBS = set(
    "order shop buy try add brew start pick get grab choose join subscribe gift send "
    "reserve bring taste treat give claim secure make enjoy pour stock upgrade grind "
    "book explore".split()
)
LABELS = ["positive", "negative", "feature request"]


@dataclass
class CaseScore:
    passed: bool
    score: float  # share of this case's checks that passed, 0 to 1
    checks: dict = field(default_factory=dict)  # check name -> True/False
    failures: list = field(default_factory=list)  # human-readable reasons


def _squash(text: str) -> str:
    """Lower-case and drop spaces and hyphens so '250g' matches '250 g'."""
    return re.sub(r"[\s\-]+", "", text.lower())


def _numbers(text: str) -> set:
    return {n.replace(",", "") for n in re.findall(r"\d+(?:[.,]\d+)?", text)}


def _finish(checks: dict, failures: list) -> CaseScore:
    passed_n = sum(1 for ok in checks.values() if ok)
    return CaseScore(
        passed=all(checks.values()),
        score=passed_n / len(checks),
        checks=checks,
        failures=failures,
    )


def score_product_description(case: dict, output: str) -> CaseScore:
    """Six rules: length, no hype, all facts, no new numbers, benefit opening, call to action.

    Case fields: vars.product_name, vars.details, must_include (list; "a|b" means either wording).
    """
    product = case["vars"]["product_name"]
    details = case["vars"]["details"]
    text = output.strip()
    checks, failures = {}, []

    words = len(text.split())
    checks["R1_length"] = 60 <= words <= 90
    if not checks["R1_length"]:
        failures.append(f"R1 length: {words} words, need 60 to 90")

    hits = [w for w in BANNED_WORDS if re.search(r"\b" + re.escape(w) + r"\b", text.lower())]
    if "!" in text:
        hits.append("!")
    checks["R2_no_hype"] = not hits
    if hits:
        failures.append("R2 hype: " + ", ".join(hits))

    squashed = _squash(text)
    missing = [m.split("|")[0] for m in case.get("must_include", [])
               if not any(_squash(alt) in squashed for alt in m.split("|"))]
    checks["R3_all_facts"] = not missing
    if missing:
        failures.append("R3 missing facts: " + ", ".join(missing))

    invented = sorted(_numbers(text) - _numbers(product + " " + details), key=float)
    checks["R4_no_new_numbers"] = not invented
    if invented:
        failures.append("R4 invented numbers: " + ", ".join(invented))

    first_word = text.split()[0].lower().strip(",.") if text else ""
    checks["R5_benefit_opening"] = bool(text) and not text.lower().startswith(product.lower()) \
        and first_word not in {"introducing", "meet", "discover"}
    if not checks["R5_benefit_opening"]:
        failures.append("R5 opening: starts with product name, Introducing, Meet or Discover")

    sentences = [s for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]
    last = sentences[-1] if sentences else ""
    last_words = len(last.split())
    verb = last.split()[0].lower().strip(",.!") if last else ""
    checks["R6_call_to_action"] = 2 <= last_words <= 8 and verb in CTA_VERBS
    if not checks["R6_call_to_action"]:
        failures.append(f"R6 call to action: last sentence has {last_words} words and starts '{verb}'")

    return _finish(checks, failures)


def score_exact_label(case: dict, output: str) -> CaseScore:
    """Pass when the last label the model names is the expected one.

    Case fields: expected (one of LABELS). Works for bare labels and for 'reasoning => label'.
    """
    found = re.findall("|".join(re.escape(label) for label in LABELS), output.lower())
    got = found[-1] if found else None
    ok = got == case["expected"]
    failures = [] if ok else [f"label: got {got!r}, expected {case['expected']!r}"]
    return _finish({"label_correct": ok}, failures)


SCORERS = {
    "product_description": score_product_description,
    "exact_label": score_exact_label,
}
