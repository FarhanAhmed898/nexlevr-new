"""Command line: run, baseline, check."""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from .library import load_library
from .models import get_model
from .regress import compare, load_baseline, render_report, save_baseline
from .runner import run_version

DEFAULT_MODELS = "anthropic:claude-haiku-5-5,anthropic:claude-sonnet-5-5"


def _models(arg: str | None):
    spec = arg or os.environ.get("HARNESS_MODELS", DEFAULT_MODELS)
    return [get_model(s.strip()) for s in spec.split(",") if s.strip()]


def _select(library: dict, names: list) -> list:
    if not names:
        return list(library.values())
    unknown = [n for n in names if n not in library]
    if unknown:
        sys.exit(f"unknown prompt(s): {', '.join(unknown)}. Available: {', '.join(library)}")
    return [library[n] for n in names]


def _save_run(runs_dir: Path, run: dict) -> None:
    folder = runs_dir / run["prompt"]
    folder.mkdir(parents=True, exist_ok=True)
    safe_model = run["model"].replace(":", "_").replace("/", "_")
    (folder / f"{run['version']}__{safe_model}.json").write_text(json.dumps(run, indent=1))


def cmd_run(args) -> int:
    library = load_library(args.library)
    for prompt in _select(library, [args.prompt]):
        version = args.version or prompt.current
        for model in _models(args.models):
            run = run_version(prompt, version, model, args.workers)
            _save_run(Path(args.runs), run)
            s = run["summary"]
            print(f"{prompt.name} {version} on {model.name}: {s['pass_rate']:.0%} of {s['n']} cases pass, "
                  f"mean score {s['mean_score']:.2f}, {s['errors']} errors")
            for name, rate in s["by_check"].items():
                print(f"    {name}: {rate:.0%}")
    return 0


def cmd_baseline(args) -> int:
    library = load_library(args.library)
    for prompt in _select(library, args.prompts):
        runs = {m.name: run_version(prompt, prompt.current, m, args.workers) for m in _models(args.models)}
        save_baseline(Path(args.baselines) / f"{prompt.name}.json", prompt.name, runs)
        for name, run in runs.items():
            print(f"baseline saved: {prompt.name} {prompt.current} on {name}: {run['summary']['pass_rate']:.0%}")
    return 0


def cmd_check(args) -> int:
    library = load_library(args.library)
    exit_code, reports = 0, []
    for prompt in _select(library, args.prompts):
        baseline = load_baseline(Path(args.baselines) / f"{prompt.name}.json")
        if baseline is None:
            print(f"NO BASELINE for {prompt.name}: run `python -m harness baseline {prompt.name}` first", file=sys.stderr)
            exit_code = max(exit_code, 2 if args.require_baseline else exit_code)
            continue
        verdicts = []
        for model in _models(args.models):
            if model.name not in baseline:
                print(f"no baseline for {prompt.name} on {model.name}; skipped", file=sys.stderr)
                continue
            candidate = run_version(prompt, prompt.current, model, args.workers)
            _save_run(Path(args.runs), candidate)
            verdicts.append(compare(baseline[model.name], candidate, args.tolerance, args.strict_cases))
        if verdicts:
            reports.append(render_report(prompt.name, verdicts))
            if any(v["flags"] for v in verdicts):
                exit_code = 1
    report = "\n".join(reports) or "Nothing was checked.\n"
    print(report)
    if args.report:
        Path(args.report).write_text(report)
    return exit_code


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="harness", description="Score a prompt library and flag regressions.")
    parser.add_argument("--library", default="library")
    parser.add_argument("--runs", default="runs")
    parser.add_argument("--baselines", default="baselines")
    parser.add_argument("--models", help=f"comma-separated model specs (default {DEFAULT_MODELS})")
    parser.add_argument("--workers", type=int, default=4)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("run", help="run one prompt version and print its scores")
    p.add_argument("prompt")
    p.add_argument("--version")
    p.set_defaults(func=cmd_run)

    p = sub.add_parser("baseline", help="run the current version and store it as the baseline")
    p.add_argument("prompts", nargs="*")
    p.set_defaults(func=cmd_baseline)

    p = sub.add_parser("check", help="run the current version, compare with the baseline, exit 1 on a drop")
    p.add_argument("prompts", nargs="*")
    p.add_argument("--tolerance", type=float, default=0.05, help="allowed drop, e.g. 0.05 = 5 points")
    p.add_argument("--strict-cases", action="store_true", help="also flag any single case that went from pass to fail")
    p.add_argument("--require-baseline", action="store_true", help="exit 2 if a prompt has no baseline")
    p.add_argument("--report", help="write the markdown report to this file")
    p.set_defaults(func=cmd_check)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
