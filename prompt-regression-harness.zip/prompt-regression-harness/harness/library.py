"""Load the prompt library: one folder per prompt, with prompt.json and cases.json."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Prompt:
    name: str
    scorer: str
    versions: dict  # version label -> template text
    current: str
    cases: list

    def template(self, version: str | None = None) -> str:
        return self.versions[version or self.current]

    def sha(self, version: str | None = None) -> str:
        return hashlib.sha256(self.template(version).encode()).hexdigest()[:12]

    def render(self, version: str, case: dict) -> str:
        text = self.template(version)
        for key, value in case["vars"].items():
            text = text.replace("{{" + key + "}}", str(value))
        return text


def load_library(root: str | Path = "library") -> dict:
    prompts = {}
    for folder in sorted(Path(root).iterdir()):
        spec_file = folder / "prompt.json"
        if not spec_file.is_file():
            continue
        spec = json.loads(spec_file.read_text())
        cases = json.loads((folder / "cases.json").read_text())
        if spec["current"] not in spec["versions"]:
            raise ValueError(f"{folder.name}: current version {spec['current']!r} is not in versions")
        prompts[folder.name] = Prompt(folder.name, spec["scorer"], spec["versions"], spec["current"], cases)
    return prompts
