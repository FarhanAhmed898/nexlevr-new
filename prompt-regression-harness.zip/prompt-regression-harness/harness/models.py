"""Model backends. Each has generate(prompt) -> str.

Specs for --models:
  anthropic:<model id>   real calls to the Anthropic Messages API (needs ANTHROPIC_API_KEY)
  mock:strict            offline stand-in that follows the rules a prompt states
  mock:loose             offline stand-in that follows only some of them

The mock models exist so the harness can be tested and demoed with no network or API key.
Their scores say nothing about real model quality.
"""
from __future__ import annotations

import json
import os
import re
import time
import urllib.error
import urllib.request


class AnthropicModel:
    def __init__(self, model_id: str, max_tokens: int = 800, temperature: float | None = 0.0):
        self.name = f"anthropic:{model_id}"
        self.model_id = model_id
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.api_key = os.environ.get("ANTHROPIC_API_KEY", "")
        self.base_url = os.environ.get("ANTHROPIC_BASE_URL", "https://api.anthropic.com").rstrip("/")

    def generate(self, prompt: str) -> str:
        if not self.api_key:
            raise RuntimeError("ANTHROPIC_API_KEY is not set")
        body = {
            "model": self.model_id,
            "max_tokens": self.max_tokens,
            "messages": [{"role": "user", "content": prompt}],
        }
        if self.temperature is not None:
            body["temperature"] = self.temperature
        request = urllib.request.Request(
            f"{self.base_url}/v1/messages",
            data=json.dumps(body).encode(),
            headers={
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
        )
        for attempt in range(4):
            try:
                with urllib.request.urlopen(request, timeout=120) as response:
                    data = json.load(response)
                return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
            except urllib.error.HTTPError as err:
                if err.code in (429, 500, 502, 503, 529) and attempt < 3:
                    time.sleep(2 ** attempt)
                    continue
                raise RuntimeError(f"API error {err.code}: {err.read().decode()[:300]}") from err
        raise RuntimeError("unreachable")


class MockModel:
    """Deterministic offline model. It reads which rules the prompt states and obeys them."""

    def __init__(self, mode: str):
        if mode not in ("strict", "loose"):
            raise ValueError("mock mode must be 'strict' or 'loose'")
        self.mode = mode
        self.name = f"mock:{mode}"

    def generate(self, prompt: str) -> str:
        if "Product:" in prompt and "Facts:" in prompt:
            return self._describe(prompt)
        return self._label(prompt)

    # -- product descriptions -------------------------------------------------
    def _describe(self, prompt: str) -> str:
        product = re.search(r"^Product: (.+)$", prompt, re.M).group(1)
        facts = [f.strip() for f in re.search(r"^Facts: (.+)$", prompt, re.M).group(1).split(";") if f.strip()]
        has_rules = "RULES" in prompt
        states_banned = "Do not use these words" in prompt
        states_no_new = "Do not add any fact" in prompt
        states_cta = "call to action" in prompt
        states_count = "Count the words" in prompt
        if self.mode == "loose":
            facts = facts[:-1] if len(facts) > 4 else facts  # loose model drops a fact on long lists
        body = " ".join(f"It comes with {f}." if i else f"Here is what you get: {f}." for i, f in enumerate(facts))
        text = f"Start your day better with this {product.lower()}. {body}"
        if states_count and self.mode == "strict":
            text += (" It suits a quick weekday routine or a slower weekend, so you can use it the way that"
                     " suits you, whether you are on your own or sharing it with a friend at home today.")
        if not has_rules or not states_banned:
            text = text.replace("Start your day better", "Wake up to a perfect morning") + " A must-have!"
        if not has_rules or not states_no_new:
            text += " Rated by 7 out of 10 customers."
        text += " Order yours today." if has_rules and states_cta else " Pick this up today and enjoy it all week long."
        return text

    # -- review labels --------------------------------------------------------
    def _label(self, prompt: str) -> str:
        review = prompt.strip().splitlines()[-1].lower()
        request = ("please add", "would love", "could you", "can you", "would be great", "any plans",
                   "would be fantastic", "please make", "i really wish", "please fix")
        if self.mode == "strict":
            request += ("wish",)
        negative = ("stale", "leak", "charged", "broke", "late", "waiting", "stopped", "crushed", "flat", "disappoint")
        if any(k in review for k in request):
            return "feature request"
        if any(k in review for k in negative):
            return "negative"
        return "positive"


def get_model(spec: str):
    kind, _, rest = spec.partition(":")
    if kind == "anthropic" and rest:
        temperature = os.environ.get("HARNESS_TEMPERATURE", "0")
        return AnthropicModel(rest, temperature=None if temperature.lower() == "none" else float(temperature))
    if kind == "mock" and rest:
        return MockModel(rest)
    raise ValueError(f"unknown model spec {spec!r}; use anthropic:<id> or mock:strict|loose")
